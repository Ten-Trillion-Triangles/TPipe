# PipeContextProtocol (PCP)

**OVERVIEW**
PCP enables secure multi-language tool execution (Kotlin/JS/Python) with strict transport routing, session management, and sandboxed security boundaries.

## STRUCTURE
```
PipeContextProtocol/
├── Pcp.kt                    # Transport, Permissions, ParamType, StdioContextOptions enums
├── PcpExecutionDispatcher.kt  # Routes requests to appropriate executor
├── PcpFunctionHandler.kt      # Tpipe transport function handler
├── FunctionInvoker.kt         # Native function invocation engine
├── FunctionRegistry.kt        # Function/type converter registry
├── FunctionWrapper.kt         # Function metadata wrapper
├── FunctionSignature.kt       # Parameter/return type signatures
├── PcpRegistry.kt            # PCP registry operations
├── PcpInstructionGenerator.kt # Generates PCP instructions
├── PcpResponseParser.kt       # Parses response transport
├── PcpStdioHost.kt           # STDIO host implementation
├── TypeConverter.kt          # Cross-language type conversion
├── ReturnValueHandler.kt     # Return value processing
├── LanguageExecutors/
│   ├── KotlinExecutor.kt
│   ├── JavaScriptExecutor.kt
│   └── PythonExecutor.kt
├── LanguageSecurity/
│   ├── KotlinSecurityManager.kt
│   ├── JavaScriptSecurityManager.kt
│   ├── PythonSecurityManager.kt
│   ├── HttpSecurityManager.kt
│   └── CommandSecurityManager.kt
├── TransportExecutors/
│   ├── StdioExecutor.kt       # STDIO transport with session management
│   ├── StdioSessionManager.kt
│   ├── StdioBufferManager.kt
│   └── HttpExecutor.kt        # HTTP transport
├── PlatformManagers/
│   ├── PythonPlatformManager.kt
│   └── (Kotlin/JS platform managers)
└── Constants/
    ├── KotlinConstants.kt, JavaScriptConstants.kt
    ├── PythonConstants.kt, HttpConstants.kt
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Add new language executor | `LanguageExecutors/` | Implement transport routing in `PcpExecutionDispatcher` |
| Security policy for language | `LanguageSecurity/` | Per-language `SecurityManager` validates permissions |
| PCP request/response flow | `PcpExecutionDispatcher.kt` | `routeRequest()` → executor → result |
| Function parameter validation | `FunctionInvoker.kt` | Uses `FunctionRegistry` and `TypeConverter` |
| STDIO session management | `StdioSessionManager.kt`, `StdioBufferManager.kt` | Persistent session support |
| Multi-language type conversion | `TypeConverter.kt` | Handles String/Int/Bool/Float/Enum/List/Map/Object |
| PCP protocol enums | `Pcp.kt` | Transport, Permissions, ParamType, StdioExecutionMode |

## CONVENTIONS
- **Transport enum**: `Auto, Stdio, Tpipe, Http, Python, Kotlin, JavaScript, Unknown`
- **StdioExecutionMode**: `ONE_SHOT, INTERACTIVE, CONNECT, BUFFER_REPLAY`
- **Security boundary**: Each language has a dedicated `SecurityManager` (not shared)
- **Execution flow**: `Pcp` → `PcpExecutionDispatcher.routeRequest()` → LanguageExecutor → SecurityManager → response

## ANTI-PATTERNS
- **Never** bypass `PcpExecutionDispatcher.routeRequest()` — transport validation ensures security boundaries
- **Never** share `SecurityManager` across language executors — sandbox isolation required
- **Never** call `FunctionInvoker.invoke()` without validating `parameters` map first