package com.TTT.Pipeline

import com.TTT.Debug.TraceConfig
import com.TTT.P2P.KillSwitch
import com.TTT.P2P.KillSwitchContext
import com.TTT.P2P.P2PDescriptor
import com.TTT.P2P.P2PConcurrencyMode
import com.TTT.P2P.P2PInterface
import com.TTT.P2P.P2PRequirements
import kotlinx.coroutines.runBlocking

/**
 * Restricts nested Junction DSL receivers so moderator, participant, and tracing configuration do not leak across
 * blocks.
 */
@DslMarker
annotation class JunctionDslMarker

/**
 * Sealed class representing the state machine stages for type-safe Junction DSL building.
 *
 * - [Initial]         : Nothing configured yet
 * - [HasModerator]    : moderator { } has been called
 * - [HasParticipants] : At least one participant { } has been called
 * - [Ready]           : All required and optional configuration is complete (build() available)
 */
sealed class JunctionStage
{
    object Initial         : JunctionStage()
    object HasModerator    : JunctionStage()
    object HasParticipants : JunctionStage()
    object Ready           : JunctionStage()
}

/**
 * Root Junction DSL builder. Generic over the current configuration stage to enforce compile-time safety.
 *
 * @param S Current stage in the builder state machine.
 */
class JunctionBuilder<S : JunctionStage> @PublishedApi internal constructor(
    private var moderatorConfigured: Boolean = false,
    private val junction: Junction = Junction(),
    var concurrencyModeConfiguration: P2PConcurrencyMode = P2PConcurrencyMode.SHARED,
    var killSwitchConfiguration: KillSwitch? = null
)
{
    /**
     * Factory for creating new builder instances with different type parameters while preserving all configuration.
     */
    private fun <T : JunctionStage> createNew(
        moderatorConfigured: Boolean = this.moderatorConfigured,
        junction: Junction = this.junction,
        concurrencyModeConfiguration: P2PConcurrencyMode = this.concurrencyModeConfiguration,
        killSwitchConfiguration: KillSwitch? = this.killSwitchConfiguration
    ): JunctionBuilder<T> = JunctionBuilder<T>(
        moderatorConfigured = moderatorConfigured,
        junction = junction,
        concurrencyModeConfiguration = concurrencyModeConfiguration,
        killSwitchConfiguration = killSwitchConfiguration
    )

    /**
     * Set the P2P concurrency mode for this junction when registered with the P2P registry.
     *
     * @param mode SHARED routes all requests to one instance. ISOLATED clones per request.
     * @return This builder for chaining.
     */
    fun concurrencyMode(mode: P2PConcurrencyMode): JunctionBuilder<S>
    {
        concurrencyModeConfiguration = mode
        return this
    }

    /**
     * Read the configured concurrency mode.
     *
     * @return The concurrency mode set on this DSL.
     */
    fun getConcurrencyMode(): P2PConcurrencyMode = concurrencyModeConfiguration

    /**
     * Configure an emergency kill switch to halt execution if token limits are exceeded.
     *
     * The kill switch monitors input and output token usage across moderator and all participants.
     * When tripped, it immediately terminates the junction regardless of any retry policies.
     *
     * @param inputTokenLimit Maximum input tokens allowed (prompt + context). null = no limit.
     * @param outputTokenLimit Maximum output tokens allowed (response + reasoning). null = no limit.
     * @param onTripped Optional callback invoked when the kill switch trips.
     * @return This builder for chaining.
     */
    fun killSwitch(inputTokenLimit: Int? = null, outputTokenLimit: Int? = null, onTripped: ((KillSwitchContext) -> Nothing)? = null): JunctionBuilder<S>
    {
        killSwitchConfiguration = if(onTripped != null) {
            KillSwitch(inputTokenLimit = inputTokenLimit, outputTokenLimit = outputTokenLimit, onTripped = onTripped)
        } else {
            KillSwitch(inputTokenLimit = inputTokenLimit, outputTokenLimit = outputTokenLimit)
        }
        return this
    }

    /**
     * Configure the discussion moderator.
     *
     * @param roleName Stable moderator routing name.
     * @param component The P2P-capable moderator container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable moderator description.
     * @return A new builder with HasModerator stage.
     */
    fun moderator(
        roleName: String,
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<JunctionStage.HasModerator>
    {
        require(!moderatorConfigured) { "Junction DSL already has a moderator block." }
        moderatorConfigured = true
        junction.setModerator(
            roleName = roleName,
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return createNew<JunctionStage.HasModerator>(moderatorConfigured = true)
    }

    /**
     * Configure the discussion moderator without an explicit role name.
     *
     * @param component The P2P-capable moderator container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable moderator description.
     * @return A new builder with HasModerator stage.
     */
    fun moderator(
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<JunctionStage.HasModerator>
    {
        require(!moderatorConfigured) { "Junction DSL already has a moderator block." }
        moderatorConfigured = true
        junction.setModerator(
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return createNew<JunctionStage.HasModerator>(moderatorConfigured = true)
    }

    /**
     * Declare a participant that can speak during the Junction discussion.
     *
     * @param roleName Stable participant routing name.
     * @param component The P2P-capable participant container or pipeline.
     * @param weight Vote weight for this participant.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable participant description.
     * @return This builder for chaining (participants can be added multiple times).
     */
    fun participant(
        roleName: String,
        component: P2PInterface,
        weight: Double = 1.0,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.addParticipant(
            roleName = roleName,
            component = component,
            weight = weight,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Declare a participant using a generated routing name.
     *
     * @param component The P2P-capable participant container or pipeline.
     * @param weight Vote weight for this participant.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable participant description.
     * @return This builder for chaining.
     */
    fun participant(
        component: P2PInterface,
        weight: Double = 1.0,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.addParticipant(
            component = component,
            weight = weight,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Select the workflow recipe for the Junction.
     *
     * @param recipe The workflow recipe to use.
     * @return This builder for chaining.
     */
    fun workflowRecipe(recipe: JunctionWorkflowRecipe): JunctionBuilder<S>
    {
        junction.setWorkflowRecipe(recipe)
        return this
    }

    /**
     * Switch the DSL back to discussion-only execution.
     *
     * @return This builder for chaining.
     */
    fun discussionOnly(): JunctionBuilder<S>
    {
        junction.discussionOnly()
        return this
    }

    /**
     * Configure the vote -> act -> verify -> repeat workflow recipe.
     *
     * @return This builder for chaining.
     */
    fun voteActVerifyRepeat(): JunctionBuilder<S>
    {
        junction.voteActVerifyRepeat()
        return this
    }

    /**
     * Configure the act -> vote -> verify -> repeat workflow recipe.
     *
     * @return This builder for chaining.
     */
    fun actVoteVerifyRepeat(): JunctionBuilder<S>
    {
        junction.actVoteVerifyRepeat()
        return this
    }

    /**
     * Configure the vote -> plan -> act -> verify -> repeat workflow recipe.
     *
     * @return This builder for chaining.
     */
    fun votePlanActVerifyRepeat(): JunctionBuilder<S>
    {
        junction.votePlanActVerifyRepeat()
        return this
    }

    /**
     * Configure the plan -> vote -> act -> verify -> repeat workflow recipe.
     *
     * @return This builder for chaining.
     */
    fun planVoteActVerifyRepeat(): JunctionBuilder<S>
    {
        junction.planVoteActVerifyRepeat()
        return this
    }

    /**
     * Configure the vote -> plan -> output -> exit workflow recipe.
     *
     * @return This builder for chaining.
     */
    fun votePlanOutputExit(): JunctionBuilder<S>
    {
        junction.votePlanOutputExit()
        return this
    }

    /**
     * Configure the plan -> vote -> adjust -> output -> exit workflow recipe.
     *
     * @return This builder for chaining.
     */
    fun planVoteAdjustOutputExit(): JunctionBuilder<S>
    {
        junction.planVoteAdjustOutputExit()
        return this
    }

    /**
     * Configure the P2P descriptor for this Junction.
     *
     * @param descriptor The descriptor to use for this Junction.
     * @return This builder for chaining.
     */
    fun descriptor(descriptor: P2PDescriptor): JunctionBuilder<S>
    {
        junction.setP2pDescription(descriptor)
        return this
    }

    /**
     * Configure the P2P requirements for this Junction.
     *
     * @param requirements The requirements to use for this Junction.
     * @return This builder for chaining.
     */
    fun requirements(requirements: P2PRequirements): JunctionBuilder<S>
    {
        junction.setP2pRequirements(requirements)
        return this
    }

    /**
     * Configure the outbound memory policy used by the Junction harness.
     *
     * @param block Builder block for the memory policy.
     * @return This builder for chaining.
     */
    fun memoryPolicy(block: JunctionMemoryPolicy.() -> Unit): JunctionBuilder<S>
    {
        junction.memoryPolicy(block)
        return this
    }

    /**
     * Configure the planner role for workflow-oriented Junction execution.
     *
     * @param roleName Stable planner routing name.
     * @param component The P2P-capable planner container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable planner description.
     * @return This builder for chaining.
     */
    fun planner(
        roleName: String,
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setPlanner(
            roleName = roleName,
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the planner role without an explicit role name.
     *
     * @param component The P2P-capable planner container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable planner description.
     * @return This builder for chaining.
     */
    fun planner(
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setPlanner(
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the actor role for workflow-oriented Junction execution.
     *
     * @param roleName Stable actor routing name.
     * @param component The P2P-capable actor container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable actor description.
     * @return This builder for chaining.
     */
    fun actor(
        roleName: String,
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setActor(
            roleName = roleName,
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the actor role without an explicit role name.
     *
     * @param component The P2P-capable actor container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable actor description.
     * @return This builder for chaining.
     */
    fun actor(
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setActor(
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the verifier role for workflow-oriented Junction execution.
     *
     * @param roleName Stable verifier routing name.
     * @param component The P2P-capable verifier container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable verifier description.
     * @return This builder for chaining.
     */
    fun verifier(
        roleName: String,
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setVerifier(
            roleName = roleName,
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the verifier role without an explicit role name.
     *
     * @param component The P2P-capable verifier container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable verifier description.
     * @return This builder for chaining.
     */
    fun verifier(
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setVerifier(
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the adjuster role for workflow-oriented Junction execution.
     *
     * @param roleName Stable adjuster routing name.
     * @param component The P2P-capable adjuster container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable adjuster description.
     * @return This builder for chaining.
     */
    fun adjuster(
        roleName: String,
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setAdjuster(
            roleName = roleName,
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the adjuster role without an explicit role name.
     *
     * @param component The P2P-capable adjuster container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable adjuster description.
     * @return This builder for chaining.
     */
    fun adjuster(
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setAdjuster(
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the output role for workflow-oriented Junction execution.
     *
     * @param roleName Stable output handler routing name.
     * @param component The P2P-capable output handler container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable output handler description.
     * @return This builder for chaining.
     */
    fun outputHandler(
        roleName: String,
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setOutputHandler(
            roleName = roleName,
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Configure the output role without an explicit role name.
     *
     * @param component The P2P-capable output handler container or pipeline.
     * @param descriptor Optional explicit P2P descriptor.
     * @param requirements Optional explicit P2P requirements.
     * @param description Optional human-readable output handler description.
     * @return This builder for chaining.
     */
    fun outputHandler(
        component: P2PInterface,
        descriptor: P2PDescriptor? = null,
        requirements: P2PRequirements? = null,
        description: String = ""
    ): JunctionBuilder<S>
    {
        junction.setOutputHandler(
            component = component,
            descriptor = descriptor,
            requirements = requirements,
            description = description
        )
        return this
    }

    /**
     * Select the discussion strategy.
     *
     * @param strategy The strategy to use for turn scheduling.
     * @return This builder for chaining.
     */
    fun strategy(strategy: DiscussionStrategy): JunctionBuilder<S>
    {
        junction.setStrategy(strategy)
        return this
    }

    /**
     * Set the maximum number of discussion rounds.
     *
     * @param rounds Maximum number of rounds to execute.
     * @return This builder for chaining.
     */
    fun rounds(rounds: Int): JunctionBuilder<S>
    {
        junction.setRounds(rounds)
        return this
    }

    /**
     * Set the consensus threshold.
     *
     * @param threshold Voting threshold from 0.0 to 1.0.
     * @return This builder for chaining.
     */
    fun threshold(threshold: Double): JunctionBuilder<S>
    {
        junction.setVotingThreshold(threshold)
        return this
    }

    /**
     * Enable or disable moderator intervention.
     *
     * @param enabled Whether the moderator may override the discussion.
     * @return This builder for chaining.
     */
    fun intervention(enabled: Boolean): JunctionBuilder<S>
    {
        junction.setModeratorIntervention(enabled)
        return this
    }

    /**
     * Set the maximum nested P2P dispatch depth.
     *
     * @param depth Maximum recursion depth for nested containers.
     * @return This builder for chaining.
     */
    fun maxNestedDepth(depth: Int): JunctionBuilder<S>
    {
        junction.setMaxNestedDepth(depth)
        return this
    }

    /**
     * Configure tracing for the Junction harness.
     *
     * @param config The tracing configuration to use.
     * @return This builder for chaining.
     */
    fun tracing(config: TraceConfig = TraceConfig(enabled = true)): JunctionBuilder<S>
    {
        junction.enableTracing(config)
        return this
    }

    /**
     * Build and initialize the configured [Junction].
     * ONLY available on JunctionBuilder<Ready> - compile error otherwise.
     *
     * @warning This method uses [runBlocking] to initialize the junction. Use [buildSuspend] in coroutine contexts.
     * @return Fully initialized junction ready for execution.
     */
    @PublishedApi
    internal fun buildInternal(): Junction
    {
        runBlocking {
            junction.init()
        }
        if(killSwitchConfiguration != null)
        {
            junction.killSwitch = killSwitchConfiguration
        }
        return junction
    }

    /**
     * Validate all DSL declarations and materialize a configured [Junction] that is ready for [Junction.init].
     *
     * @return Configured but not yet initialized junction.
     */
    @PublishedApi
    internal fun configureJunctionInternal(): Junction
    {
        validateJunction()
        if(killSwitchConfiguration != null)
        {
            junction.killSwitch = killSwitchConfiguration
        }
        return junction
    }

    /**
     * Validate the junction configuration before building.
     */
    private fun validateJunction()
    {
        require(moderatorConfigured) { "Junction requires a moderator { } block." }
    }
}

/**
 * Entry point for the type-safe Junction DSL.
 *
 * @param block Builder block that configures the junction (moderator, participants, optional settings).
 * @return Fully configured and initialized Junction.
 */
fun junction(block: JunctionBuilder<JunctionStage.Initial>.() -> Unit): Junction
{
    val builder = JunctionBuilder<JunctionStage.Initial>()
    builder.block()
    return builder.buildInternal()
}

/**
 * Factory function to create the initial JunctionBuilder in the Initial stage.
 * This is the only way to start building a Junction via the DSL.
 *
 * @return A new builder in the Initial stage.
 */
fun junctionBuilder(): JunctionBuilder<JunctionStage.Initial>
{
    return JunctionBuilder<JunctionStage.Initial>()
}

/**
 * Build and initialize the configured [Junction].
 *
 * @receiver A [JunctionBuilder] in the Ready state — all required configuration is complete.
 * @return Fully initialized junction ready for use.
 * @throws IllegalArgumentException if required configuration is missing (should never happen due to type safety).
 */
fun JunctionBuilder<JunctionStage.Ready>.build(): Junction
{
    return this.buildInternal()
}

/**
 * Build and initialize the configured [Junction] in a suspend context.
 *
 * @receiver A [JunctionBuilder] in the Ready state — all required configuration is complete.
 * @return Fully initialized junction ready for use.
 * @throws IllegalArgumentException if required configuration is missing (should never happen due to type safety).
 */
suspend fun JunctionBuilder<JunctionStage.Ready>.buildSuspend(): Junction
{
    val junction = this.configureJunctionInternal()
    junction.init()
    return junction
}