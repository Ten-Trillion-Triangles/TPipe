# Pipeline

## OVERVIEW
Orchestration containers (Pipeline, Manifold, Junction, Connector, Splitter, MultiConnector, DistributionGrid) for chaining pipes and coordinating multi-agent workflows.

## STRUCTURE
```
Pipeline/
├── Pipeline.kt             # Base class, pipe sequencing (1,541 LOC)
├── Manifold.kt             # Manager/worker orchestration, P2P dispatch (2,223 LOC)
├── Junction.kt             # Democratic voting, workflow recipe phases (4,086 LOC)
├── DistributionGrid.kt     # Distributed node routing, registry discovery (8,738 LOC)
├── Connector.kt            # Conditional pipeline branching
├── Splitter.kt             # Parallel pipeline execution
├── MultiConnector.kt       # Complex routing (SEQUENTIAL/PARALLEL/FALLBACK)
├── ManifoldDsl.kt          # DSL builder: manifold { }
├── JunctionDsl.kt          # DSL builder: junction { }
├── DistributionGridDsl.kt  # DSL builder: distributionGrid { }
├── ManifoldLoopLimitExceededException.kt
└── *Models.kt, *MemoryModels.kt, *DurabilityModels.kt, *ProtocolModels.kt
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Multi-agent orchestration | `Manifold.kt` | Manager/worker, P2P dispatch, loop limits |
| Democratic decision-making | `Junction.kt` | Voting, moderator/participant, workflow recipes |
| Distributed routing | `DistributionGrid.kt` | Node registry, remote handoff, durability |
| DSL entry | `ManifoldDsl.kt`, `JunctionDsl.kt` | State machine stages |

## CONVENTIONS
- All containers implement `P2PInterface`
- KillSwitch accumulation pattern across all containers
- Tracing support via `enableTracing()`, `trace()` methods
- DSL builders use `configure()` with stage validation
- `@RuntimeState` fields preserved across lifecycle transitions

## ANTI-PATTERNS
- **Never** share a single container instance across simultaneous executions (mutable state per run)
- **Never** call `setTokenBudget()` while executing (thread safety)