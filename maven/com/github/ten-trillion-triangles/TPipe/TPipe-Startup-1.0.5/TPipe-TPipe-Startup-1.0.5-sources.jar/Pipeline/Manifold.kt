package com.TTT.Pipeline

import com.TTT.Context.ContextWindow
import com.TTT.Context.ConverseHistory
import com.TTT.Context.ConverseRole
import com.TTT.Context.Dictionary
import com.TTT.Enums.ProviderName
import com.TTT.Enums.SummaryMode
import com.TTT.P2P.AgentDescriptor
import com.TTT.P2P.AgentRequest
import com.TTT.P2P.InputSchema
import com.TTT.P2P.P2PDescriptor
import com.TTT.P2P.P2PInterface
import com.TTT.P2P.P2PRegistry
import com.TTT.P2P.P2PRequest
import com.TTT.P2P.P2PRequirements
import com.TTT.P2P.P2PResponse
import com.TTT.PipeContextProtocol.PcPRequest
import com.TTT.P2P.P2PSkills
import com.TTT.P2P.P2PTransport
import com.TTT.P2P.SupportedContentTypes
import com.TTT.Pipe.MultimodalContent
import com.TTT.Pipe.TokenBudgetSettings
import com.TTT.Structs.PipeSettings
import com.TTT.Pipe.deepCopy
import com.TTT.Pipe.toTokenBudgetSettings
import com.TTT.Pipe.toTruncationSettings
import com.TTT.PipeContextProtocol.Transport
import com.TTT.Util.extractJson
import com.TTT.Util.serializeConverseHistory
import com.TTT.Util.serialize
import com.TTT.Debug.*
import com.TTT.Enums.ContextWindowSettings
import com.TTT.Pipe.Pipe
import com.TTT.Util.examplePromptFor
import com.TTT.Util.RuntimeState
import kotlinx.coroutines.channels.Channel
import org.slf4j.helpers.NOP_FallbackServiceProvider
import java.util.UUID

/**
 * Helper class to assist the programmer with tracking the progression of agentic task being managed by the Manifold
 * class. Allows the llm to state if the task is finished, issue the next things it thinks needs to be done,
 * and how far the progress on the task is thus far.
 */
@kotlinx.serialization.Serializable
data class TaskProgress(
    var taskDescription: String = "",
    var nextTaskInstructions: String = "",
    var taskProgressStatus: String = "",
    var isTaskComplete: Boolean = false
)

/**
 * A manifold is a class that allows for controlled task management and orchestration by a manager pipeline that
 * is able to select which worker pipelines to call to handle specialized steps of the task. The worker pipelines can
 * be called either by the coder's control over the manager's "human in the loop" functions, or by allowing the
 * manager pipeline to issue a call directly to the next pipeline it needs. The worker pipeline will perform the task
 * then return back to the manager pipeline allowing it to decide which pipeline to use for the next step of the task.
 * This repeats until the task is considered to be completed and the Multimodal content object will be released as
 * the result.
 *
 * Manifold reuses its configured manager and worker pipeline instances across loop iterations. Build a fresh manifold
 * for concurrent top-level runs rather than sharing one instance across simultaneous executions.
 */
class Manifold : P2PInterface
{
//============================================== P2PInterface ==========================================================

    private var p2pDescriptor: P2PDescriptor? = null
    private var p2pTransport: P2PTransport? = null
    private var p2PRequirements: P2PRequirements? = null
    @RuntimeState
    private var containerObject: Any? = null
    @RuntimeState
    private var parentInterface: P2PInterface? = null

    override fun setP2pDescription(description: P2PDescriptor)
    {
        p2pDescriptor = description
    }

    override fun getP2pDescription(): P2PDescriptor?
    {
        return p2pDescriptor
    }

    override fun setP2pTransport(transport: P2PTransport)
    {
        p2pTransport = transport
    }

    override fun getP2pTransport(): P2PTransport?
    {
        return p2pTransport
    }

    override fun setP2pRequirements(requirements: P2PRequirements)
    {
        p2PRequirements = requirements
    }

    override fun getP2pRequirements(): P2PRequirements?
    {
        return p2PRequirements
    }

    override fun getContainerObject(): Any?
    {
        return containerObject
    }

    override fun setContainerObject(container: Any)
    {
        containerObject = container
    }

    override fun setParentInterface(parent: P2PInterface)
    {
        parentInterface = parent
    }

    override fun getParentP2PInterface(): P2PInterface? = parentInterface

    override fun getPipelinesFromInterface(): List<Pipeline>
    {
        return listOf(managerPipeline) + workerPipelines
    }

    /**
     * Wraps the execution function into a p2p response and allows agentic calls in.
     */
    override suspend fun executeP2PRequest(request: P2PRequest): P2PResponse?
    {
        val promptResult = execute(request.prompt)
        val newResponse = P2PResponse(output = promptResult)
        return newResponse
    }

    override fun setTokenBudgetRecursive(budget: TokenBudgetSettings)
    {
        managerPipeline.setTokenBudgetRecursive(budget)
        for (workerPipeline in workerPipelines)
        {
            workerPipeline.setTokenBudgetRecursive(budget)
        }
    }

    override fun getTokenBudgetSettings(): TokenBudgetSettings? = null

    override fun setPipeSettingsRecursively(settings: PipeSettings)
    {
        managerPipeline.setPipeSettingsRecursively(settings)
        for (workerPipeline in workerPipelines)
        {
            workerPipeline.setPipeSettingsRecursively(settings)
        }
    }

//=============================================Properties===============================================================

    private var managerPipeline: Pipeline = Pipeline()
    private var workerPipelines: MutableList<Pipeline> = mutableListOf()
    private val workerPipelinesByAgentName = mutableMapOf<String, Pipeline>()

    /**
     * Most critical property in this class. This is the content object that will be worked on by every llm agent
     * inside the manifold. Perhaps we should move it to its own, more distinct and visible area in this file?
     */
    @RuntimeState
    private var workingContentObject = MultimodalContent()

    /**
     * Local agent paths registered to be converted to an agent listing that can be supplied to the pipes in this
     * object. This is used to track which agents are registered to which pipelines.
     */
    private var agentPaths = mutableListOf<AgentDescriptor>()

    /**
     * Name of the pipe in the managerPipeline that is responsible for making p2p calls to the worker agents.
     * This pipe will need to have all the available agents passed back into it as pcp context, and then re-apply
     * it's system prompt to get them loaded into place.
     *
     * This is defaulted to the pipe name that will come with the standard pipeline to handle the given task.
     * By default, we'll provide standard pipelines that can be templated into functional agents to help idiot-proof,
     * and ensure that we users will have something functional out of the box that works for many general cases without
     * needing to directly fiddle with the setup in an extreme way.
     *
     * We'll invoke this in the init function in order to ensure that all agents are registered and ready to go.
     * @see init
     */
    private var agentPipeNames = mutableListOf<String>("Agent caller pipe")

    /**
     * If true the manifold applies its built-in manager-history budget control before manager execution.
     */
    private var autoTruncateContext = false

    /**
     * Default to truncate top, but is adjustable in this container's settings.
     */
    private var truncationMethod = ContextWindowSettings.TruncateTop

    /**
     * Optional explicit manager budget override for the shared conversation history maintained between loop turns.
     */
    private var managerTokenBudget: TokenBudgetSettings? = null

    /**
     * Compatibility context-window override used when manager history control is inferred from legacy truncation
     * settings rather than an explicit [TokenBudgetSettings].
     */
    private var managerContextWindowOverride: Int? = null

    /**
     * Optional developer in the loop function that allows the coder to perform various startup checks just prior
     * to starting the manifold. This is useful for various safety related tasks where the developer may need
     * some prior state to be valid, network connection, or other frail system to be checked against to prevent
     * the manifold from malfunctioning.
     *
     * @param content Multimodal content object that is about to be operated upon by the manifold. Standard TPipe
     * input for DITL functions.
     *
     * @param manifold: Reference to the manifold that is about to run. This allows the coder to inspect the inner
     * state of the manifold and stop the execution if some custom configuration is in an incorrect state.
     *
     * @return Returns true if we're allowed to proceed, or false if we need to stop the manifold here.
     */
    private var manifoldInitFunctionRef: (suspend (content: MultimodalContent, manifold: Manifold?) -> Boolean)? = null

    /**
     * Optional human in the loop function that allows for custom handling of context and context overflow.
     * Allows the coder to decide how to handle keeping context contained in the context window as expected.
     *
     * @param content The content object that is being worked on by the llm agent.
     */
    private var contextTruncationFunction: (suspend (content: MultimodalContent) -> Unit)? = null

    /**
     * Optional validation function for human in the loop intervention every time an agent completes
     * the task the manager pipeline has given it. Allows the coder to inspect, interrupt, or fail
     * the manifold task if need be.
     *
     * @param content The content object that is being worked on by the llm agent.
     * @param agent The agent that just completed the task.
     */
    private var workerValidatorFunction: (suspend (content: MultimodalContent, agent: Pipeline, manifold: Manifold) -> Boolean)? = null

    /**
     * Human in the loop function to handle a failure before the manifold is shut down. Allows the coder to
     * attempt to rectify whatever the issue is.
     */
    private var failureFunction: (suspend (content: MultimodalContent, agent: Pipeline, manifold: Manifold) -> Boolean)? = null

    /**
     * Human in the loop function to allow for content transformation upon a successful llm call. Also, can be used
     * to execute any pcp tools.
     */
    private var transformationFunction: (suspend (content: MultimodalContent) -> MultimodalContent)? = null



    /**
     * Tracing system properties for debugging and monitoring Manifold execution.
     */
    private var tracingEnabled = false
    private var traceConfig = TraceConfig()
    @RuntimeState
    private val manifoldId = UUID.randomUUID().toString()
    @RuntimeState
    private var currentTaskProgress = TaskProgress()
    @RuntimeState
    private var loopIterationCount = 0

    //==========================================Kill Switch Accumulator=================================================

    /** Accumulates input tokens from all child executions (manager + workers) */
    @Transient
    private var killSwitchInputAccumulator = 0

    /** Accumulates output tokens from all child executions (manager + workers) */
    @Transient
    private var killSwitchOutputAccumulator = 0

    /** Tracks execution start time for kill switch elapsed time calculation */
    @Transient
    private var killSwitchExecutionStartTime = 0L

    /** Maximum loop iterations before throwing ManifoldLoopLimitExceededException. null = no limit. */
    private var maxLoopIterations: Int? = 100  // Default of 100

    /**
     * Set the maximum number of loop iterations.
     * @param limit Maximum iterations allowed, null for unlimited
     * @return This Manifold for chaining
     */
    fun setMaxLoopIterations(limit: Int?): Manifold {
        maxLoopIterations = limit
        return this
    }

    /**
     * Get the configured maximum loop iterations.
     * @return Max iterations or null if unlimited
     */
    fun getMaxLoopIterations(): Int? = maxLoopIterations

    /**
     * Check if a loop limit is configured.
     * @return True if limit is set
     */
    fun hasLoopLimit(): Boolean = maxLoopIterations != null

    /**
     * Override setKillSwitch to propagate the kill switch to all child pipelines (manager and workers).
     * This ensures the kill switch is active at every level of the agent hierarchy.
     */
    private var _killSwitch: com.TTT.P2P.KillSwitch? = null
    override var killSwitch: com.TTT.P2P.KillSwitch?
        get() = _killSwitch
        set(value) {
            _killSwitch = value
            managerPipeline.killSwitch = value
            workerPipelines.forEach { it.killSwitch = value }
        }

    /**
     * Checks if the kill switch limits have been exceeded and triggers termination if so.
     * This method accumulates token counts and evaluates them against configured limits.
     *
     * @param inputTokens The current accumulated input token count
     * @param outputTokens The current accumulated output token count
     * @param elapsedMs Time elapsed since execution started
     * @throws KillSwitchException if any limit is exceeded
     */
    protected fun checkKillSwitch(inputTokens: Int, outputTokens: Int, elapsedMs: Long)
    {
        val ks = killSwitch ?: return

        val inputLimit = ks.inputTokenLimit
        val outputLimit = ks.outputTokenLimit
        val inputExceeded = inputLimit != null && inputTokens > inputLimit
        val outputExceeded = outputLimit != null && outputTokens > outputLimit

        // Emit KILLSWITCH_CHECK event on every token check when tracing is enabled
        if(tracingEnabled) {
            trace(
                eventType = TraceEventType.KILLSWITCH_CHECK,
                phase = TracePhase.MONITORING,
                metadata = mapOf(
                    "inputTokens" to inputTokens,
                    "outputTokens" to outputTokens,
                    "elapsedMs" to elapsedMs,
                    "inputLimit" to (inputLimit ?: "none"),
                    "outputLimit" to (outputLimit ?: "none"),
                    "inputExceeded" to inputExceeded,
                    "outputExceeded" to outputExceeded
                )
            )
        }

        if(inputExceeded || outputExceeded)
        {
            val reason = when
            {
                inputExceeded -> "input_exceeded"
                outputExceeded -> "output_exceeded"
                else -> null
            }

            if(reason != null)
            {
                // Emit KILLSWITCH_TRIPPED event when limits are exceeded
                if(tracingEnabled) {
                    trace(
                        eventType = TraceEventType.KILLSWITCH_TRIPPED,
                        phase = TracePhase.ERROR,
                        metadata = mapOf(
                            "reason" to reason,
                            "inputTokens" to inputTokens,
                            "outputTokens" to outputTokens,
                            "elapsedMs" to elapsedMs,
                            "inputLimit" to (inputLimit ?: "none"),
                            "outputLimit" to (outputLimit ?: "none")
                        )
                    )
                }

                ks.onTripped(com.TTT.P2P.KillSwitchContext(
                    p2pInterface = this,
                    inputTokensSpent = inputTokens,
                    outputTokensSpent = outputTokens,
                    elapsedMs = elapsedMs,
                    reason = reason,
                    accumulatedInputTokens = inputTokens,
                    accumulatedOutputTokens = outputTokens
                ))
            }
        }
    }
    @RuntimeState
    private val agentInteractionMap = mutableMapOf<String, Int>()

    /**
     * Saved copy of the initial user prompt passed to execute().
     * Available to developer-written manager pipelines for reference.
     */
    @RuntimeState
    var initialUserPrompt: String = ""
        private set

    /**
     * Optional summarization pipeline that runs after each worker response,
     * before the next manager loop iteration.
     */
    private var summaryPipeline: Pipeline? = null

    /**
     * Controls whether the summary pipeline appends to or regenerates the running summary.
     */
    private var summaryMode: SummaryMode = SummaryMode.APPEND

    /**
     * Accumulated running summary maintained across loop iterations.
     */
    @RuntimeState
    private var runningSummary: String = ""

    /**
     * Used to pause or resume a manifold. When a manifold pauses the loop will freeze and wait until it can resume.
     * This allows us to stop the progression of the manifold after a worker pipe runs to allow for accepting user input,
     * Then resume after getting that user input or system input. Unlike regular pipelines which the orchestration is
     * largely by hand with the programmer, Manifolds are too automated to make interrupting them reasonable. And so we
     * need this built in pause/resume mechanism in place.
     */
    @RuntimeState
    private var isPaused = false

    //Lock mechanism to pause and resume the manifold.
    @RuntimeState
    private val resumeSignal = Channel<Unit>(Channel.RENDEZVOUS)



//=============================================Exceptions===============================================================

    /**
     * Handle cases where pipes do not implement the required p2p setup.
     */
    fun hasP2P(pipeline: Pipeline)
    {
        var pipeHitCount = 0
        for(pipe in pipeline.getPipes())
        {
            if(pipe.getP2PAgentList() != null)
            {
                pipeHitCount++
            }
        }

        if(pipeHitCount <= 0) throw Exception("No P2P agent found in pipeline ${pipeline.pipelineName}")
    }


//=============================================Constructor==============================================================

    /**
     * Enables automatic truncation of the manifold's working converse history to stay inside the shared context limit.
     * This does not perform general worker-context summarization or cross-agent memory compression.
     */
    fun autoTruncateContext() : Manifold
    {
        autoTruncateContext = true
        return this
    }

    /**
     * Defines how to truncate context. Allows for chopping off the top, the bottom, or the middle.
     */
    fun setTruncationMethod(method: ContextWindowSettings) : Manifold
    {
        truncationMethod = method
        return this
    }

    /**
     * Read the truncation method currently configured for the manifold's built-in manager shared-history control.
     *
     * @return Current manager-history truncation method.
     */
    fun getTruncationMethod() : ContextWindowSettings
    {
        return truncationMethod
    }

    /**
     * Define a compatibility context-window override for the built-in manager-history truncation path.
     * This only applies when no explicit manager token budget is configured.
     *
     * @param size Legacy manager-history context-window override.
     * @return This manifold for chaining.
     */
    fun setContextWindowSize(size: Int) : Manifold
    {
        managerContextWindowOverride = size
        return this
    }

    /**
     * Define the token budget used for the manager-facing shared conversation history maintained by this manifold.
     * This automatically enables the built-in manager budget-control path.
     *
     * @param budget Token budget to apply to manager shared-history truncation.
     * @return This manifold for chaining.
     */
    fun setManagerTokenBudget(budget: TokenBudgetSettings) : Manifold
    {
        managerTokenBudget = budget.deepCopy()
        autoTruncateContext = true
        return this
    }

    /**
     * Read the explicit manager token budget configured on this manifold, if any.
     *
     * @return Copy of the explicitly configured manager token budget, or null when manager budgeting is inferred.
     */
    fun getManagerTokenBudget() : TokenBudgetSettings?
    {
        return managerTokenBudget?.deepCopy()
    }

    /**
     * Determine whether built-in manager-history budget control is enabled.
     *
     * @return True when manager shared-history control will run before manager execution.
     */
    fun isManagerBudgetControlEnabled() : Boolean
    {
        return autoTruncateContext
    }

    /**
     * Resolve the effective manager token budget after compatibility fallbacks are applied.
     * This is primarily useful for validation and testing.
     *
     * @return Effective manager token budget, or null when no built-in manager budgeting is configured.
     */
    internal fun getEffectiveManagerTokenBudget() : TokenBudgetSettings?
    {
        return resolveManagerBudgetConfiguration()?.budget?.deepCopy()
    }

    /**
     * Estimate the manager-facing token budget available for shared conversation history after static reservations.
     *
     * @return Effective manager-history token budget, or null when no built-in manager budgeting is configured.
     */
    internal fun getEffectiveManagerHistoryTokenBudget() : Int?
    {
        return resolveManagerBudgetConfiguration()?.historyTokenBudget
    }

    /**
     * Determine whether all registered worker pipelines have some configured overflow-protection path.
     *
     * @return True when every registered worker pipeline reports prompt-overflow protection.
     */
    fun workersHaveOverflowProtection() : Boolean
    {
        return workerPipelines.all { pipeline ->
            pipeline.hasContextOverflowProtectionConfigured()
        }
    }

    /**
     * List the worker pipeline names that currently lack prompt-overflow protection.
     *
     * @return Worker pipeline names with one or more unprotected pipes.
     */
    fun getWorkersWithoutOverflowProtection() : List<String>
    {
        return workerPipelines.filter { pipeline ->
            !pipeline.hasContextOverflowProtectionConfigured()
        }.map { pipeline ->
            pipeline.pipelineName.ifEmpty { "<unnamed worker pipeline>" }
        }
    }

    /**
     * Sets the optional DITL manifold init function. This function allows the coder to stop a manifold if we're in
     * an invalid state prior to running it. When it returns false, we'll stop execution before damage can occur.
     */
    fun setManifoldInitFunction(func: suspend (content: MultimodalContent, manifold: Manifold?) -> Boolean) : Manifold
    {
        manifoldInitFunctionRef = func
        return this
    }

    /**
     * Allows the coder to define a function that will be called when the manifold is truncating the context
     * of the workers and the agent. This allows the coder to decide how to handle the truncation.
     */
    fun setContextTruncationFunction(func: suspend (content: MultimodalContent) -> Unit) : Manifold
    {
        contextTruncationFunction = func
        return this
    }


    /**
     * Allows the coder to define a function that will be called when the manifold is validating the content
     * of the workers and the agent. This allows the coder to decide how to handle the validation, and ensure
     * that the manifold has not produced any breaking, or otherwise invalid output. If not supplied validtion
     * attempts will be skipped.
     */
    fun setValidatorFunction(func: suspend (content: MultimodalContent, agent: Pipeline, manifold: Manifold) -> Boolean) : Manifold
    {
        workerValidatorFunction = func
        return this
    }

    /**
     * Defines a branch failure function to attempt to recover the state of the manifold in the event of a validation
     * failure. This can only be called if the validation function is also valid.
     */
    fun setFailureFunction(func: suspend (content: MultimodalContent, agent: Pipeline, manifold: Manifold) -> Boolean) : Manifold
    {
        failureFunction = func
        return this
    }

    /**
     * Allows the coder to transform the output of the pipelines after it has been produced. This will always be called
     * after the manager pipeline, or the worker pipelines are done running at each step if supplied.
     */
    fun setTransformationFunction(func: suspend (content: MultimodalContent) -> MultimodalContent) : Manifold
    {
        transformationFunction = func
        return this
    }

    /**
     * Sets the optional summarization pipeline that runs after each worker response.
     * The summary pipeline must have context overflow protection configured.
     *
     * @param pipeline The pipeline to use for summarization.
     * @param descriptor Optional P2P descriptor.
     * @param requirements Optional P2P requirements.
     */
    fun setSummaryPipeline(pipeline: Pipeline, descriptor: P2PDescriptor? = null, requirements: P2PRequirements? = null): Manifold
    {
        if (!pipeline.hasContextOverflowProtectionConfigured()) {
            val unsafePipes = pipeline.getPipesWithoutContextOverflowProtection()
                .joinToString { it.pipeName.ifEmpty { "<unnamed>" } }
            throw IllegalArgumentException(
                "Summary pipeline requires overflow protection on pipes: $unsafePipes"
            )
        }
        summaryPipeline = pipeline
        return this
    }

    /**
     * Sets the summarization mode that controls how the running summary is updated.
     *
     * @param mode APPEND appends summary pipeline output to the running summary.
     *             REGENERATE replaces the running summary with the pipeline's output each iteration.
     */
    fun setSummaryMode(mode: SummaryMode): Manifold
    {
        summaryMode = mode
        return this
    }

    /**
     * Adds new registered names to look for when sending agent lists to pipes that can make agent calls.
     * This doesn't need to be invoked unless you are not using the default manager pipe from TPipe-Defaults,
     * or you have a setup with multiple branching points where an agent would be called from the manifold.
     */
    fun addP2pAgentNames(pipe: Pipe)
    {
        agentPipeNames.add(pipe.pipeName)
    }

    fun addP2pAgentNames(name: String)
    {
        agentPipeNames.add(name)
    }

    /**
     * Replace the registered manager pipe names that should receive the local worker agent list during manifold
     * startup instead of appending to the existing defaults.
     *
     * @param names Pipe names that should receive the worker agent list.
     * @return This manifold for chaining.
     */
    fun setP2pAgentNames(names: List<String>) : Manifold
    {
        require(names.isNotEmpty()) { "At least one manager dispatch pipe name is required." }

        agentPipeNames.clear()
        agentPipeNames.addAll(names.distinct())
        return this
    }

    /**
     * Assign the manager pipeline to this Manifold. The manager pipeline is the controller that determines the
     * progression of the task, and which worker pipeline must be called to perform a specific specialized action
     * to work towards completing the task.
     */
    fun setManagerPipeline(pipeline: Pipeline, descriptor: P2PDescriptor? = null, requirements: P2PRequirements? = null) : Manifold
    {
        managerPipeline = pipeline //Copy pipeline into our manager slot. Replaces the default pipeline.

        P2PRegistry.remove(managerPipeline) //Remove if we're registered somewhere else.


        /**
         * Check to ensure that at least one pipe in the manager pipeline is able to make the expected outbound
         * call to the worker agents. If not we need to throw an exception here.
         */
        var canCallAgents = false

        for(pipe in managerPipeline.getPipes())
        {
            val expectedSchema = examplePromptFor(AgentRequest::class)

            if(pipe.jsonOutput == expectedSchema)
            {
                canCallAgents = true
                break
            }
        }

        if(!canCallAgents) throw Exception("No pipe in the manager pipeline can make agent calls.")


        /**
         * Auto generate the required settings for p2p registration based on general common default cases for
         * the Manifold class. This is required if the user does not pass through their own settings.
         * The P2PRegistry will throw if the settings are null when it tries to read from the interface.
         */
        if(descriptor == null || requirements == null)
        {
            val transport = P2PTransport()
            transport.transportAddress = "${managerPipeline.pipelineName}" //Standard to use pipeline name as address.
            transport.transportMethod = Transport.Tpipe

            /**
             * By default, we should pick a secure set of requirements that disallows external access, and
             * does not allow for agent duplication or custom context. Converse input is also being required
             * since the default manager pipeline will be using it to better track what each agent did.
             */
            val requirements = P2PRequirements(
                allowAgentDuplication = false,
                allowCustomContext = false,
                allowExternalConnections = false,
                requireConverseInput = true
            )

            /**
             * Most cases would likely be text only, and not accepting binary files. This covers typical cases
             * and also retains a decent level of security.
             */
            requirements.acceptedContent = mutableListOf(SupportedContentTypes.text)

            /**
             * Define the two core basic skills the manager does. Which is to dispatch jobs, and to validate the
             * progress on the task. Technically the Manifold class will be making the direct call in of itself.
             * So the agent won't need this description. However, it's best to include it to handle unexpected edge
             * cases the user causes.
             */
            val skills = mutableListOf<P2PSkills>()
            skills.add(P2PSkills("Validate", "Validate weather a task has been completed."))
            skills.add(P2PSkills("Dispatch", "Designate an agent to complete a given task"))


            /**
             * Define descriptor with typical defaults balancing standard use cases and security for agent
             * access. By default, only the agents inside this Manifold can call here.
             */
            p2pDescriptor = P2PDescriptor(
                agentName = "${managerPipeline.pipelineName}-Manifold-Manager",
                agentDescription = "Task orchestration system with manager and worker pipelines",
                transport = transport,
                requiresAuth = false,
                usesConverse = false,
                allowsAgentDuplication = false,
                allowsCustomContext = false,
                allowsCustomAgentJson = false,
                recordsInteractionContext = false,
                recordsPromptContent = false,
                allowsExternalContext = false,
                contextProtocol = com.TTT.P2P.ContextProtocol.pcp,
                agentSkills = skills
            )

            //Bind transport to make non null.
            val requestTemplate = P2PRequest()
            requestTemplate.transport = transport

            p2pTransport = transport
            p2PRequirements = requirements

           //Define now because things will break if the interface can't pull this later.
            managerPipeline.setP2pDescription(p2pDescriptor!!)
            managerPipeline.setP2pRequirements(requirements)
            managerPipeline.setP2pTransport(transport)

            /**
             * Finally, register the pipeline with the P2PRegistry. The transport and descriptor literally can't be null
             * This makes the need for !! very annoying, but it seems the kotlin compiler can't detect this specific case.
             * They are however, never null when registered from this function, so it's safe to use !! here.
             */
            P2PRegistry.register(managerPipeline, p2pTransport!!, p2pDescriptor!!, requirements)
            return this
        }

        /**
         * We need to bind this before we register. If we don't it will become global, and we'll end up
         * missing the agents when we pull the local agents in init. This obviously would cause a catastrophic
         * failure if we don't have any agents registered. We don't want it being registered as global unless
         * the user supplied a descriptor or requirements that makes the pipeline global.
         */
        managerPipeline.setContainerObject(this)
        managerPipeline.setParentInterface(this)
        managerPipeline.setP2pTransport(descriptor.transport)
        managerPipeline.setP2pDescription(descriptor)
        managerPipeline.setP2pRequirements(requirements)

        P2PRegistry.remove(managerPipeline) //Remove to ensure we aren't double registered.

        /**
         * Register using assigned settings. None of them can be null otherwise we would not hit here.
         * So assume non-null and try to register.
         */
        P2PRegistry.register(managerPipeline, descriptor.transport, descriptor, requirements)

        return this
    }

    /**
     * Getter to read our manager pipeline. Provides some saftey since we want any sets to correctly register.
     */
    fun getManagerPipeline(): Pipeline
    {
        return managerPipeline
    }

    /**
     * Getter to read our worker pipelines. Provides access to the list of worker pipelines registered with this Manifold.
     */
    fun getWorkerPipelines(): List<Pipeline>
    {
        return workerPipelines.toList()
    }


    /**
     * Add a worker pipeline to this Manifold. Worker pipelines are specialized agents that perform
     * specific tasks as directed by the manager pipeline. Each worker is registered with the P2P system
     * to enable communication and task delegation from the manager.
     *
     * @param pipeline The worker pipeline to add to this Manifold's worker collection.
     * @param descriptor Optional P2P descriptor for custom worker configuration. If null, secure defaults are generated.
     * @param requirements Optional P2P requirements for custom worker settings. If null, secure defaults are generated.
     *
     * @return This Manifold object for method chaining.
     */
    fun addWorkerPipeline(pipeline: Pipeline,
                          descriptor: P2PDescriptor? = null,
                          requirements: P2PRequirements? = null,
                          agentName : String = "",
                          agentDescription: String = "",
                          agentSkills: List<P2PSkills>? = null): Manifold
    {
        workerPipelines.add(pipeline) //Add pipeline to our worker collection.

        P2PRegistry.remove(pipeline) //Remove if we're registered somewhere else.

        /**
         * Auto generate the required settings for p2p registration based on general common default cases for
         * worker pipelines in the Manifold class. This is required if the user does not pass through their own settings.
         * The P2PRegistry will throw if the settings are null when it tries to read from the interface.
         */
        if(descriptor == null || requirements == null)
        {
            val resolvedAgentName = agentName.ifEmpty { "${pipeline.pipelineName}-Manifold-Worker" }
            val transport = P2PTransport()
            transport.transportAddress = resolvedAgentName // Must match agentName for routing.
            transport.transportMethod = Transport.Tpipe

            /**
             * Worker pipelines should have slightly more permissive settings than the manager since they need
             * to accept tasks and context from the manager. However, external access is still restricted for security.
             * Converse input is required to track worker interactions with the manager.
             */
            val requirements = P2PRequirements(
                allowAgentDuplication = false,
                allowCustomContext = false,
                allowExternalConnections = false,
                requireConverseInput = true
            )


            requirements.acceptedContent = mutableListOf(SupportedContentTypes.text)

            /**
             * Define the core skill that all workers have - executing specialized tasks as directed by the manager.
             * Individual workers may have additional specialized skills, but this covers the basic worker capability.
             */
            var skills = mutableListOf<P2PSkills>()


            if(agentSkills == null)
            {
                skills.add(P2PSkills("Execute", "Execute specialized tasks as directed by the manager pipeline"))
            }

            else
            {
                skills = agentSkills.toMutableList()
            }

            //Define default description if not provided.
            var defaultDescription = let { agentDescription.ifEmpty { "Specialized worker pipeline for task execution within Manifold orchestration" } }

            /**
             * Define descriptor with worker-appropriate defaults. Workers are more permissive than managers
             * but still maintain security boundaries for external access.
             */
            val workerDescriptor = P2PDescriptor(
                agentName = resolvedAgentName,
                agentDescription = defaultDescription,
                transport = transport,
                requiresAuth = false,
                usesConverse = true, //Workers use converse to communicate with manager
                allowsAgentDuplication = false,
                allowsCustomContext = false,
                allowsCustomAgentJson = false,
                recordsInteractionContext = true, //Track interactions for debugging
                recordsPromptContent = true,
                allowsExternalContext = false,
                contextProtocol = com.TTT.P2P.ContextProtocol.pcp,
                agentSkills = skills
            )

            /**
             * We need to bind this before we register. If we don't it will become global, and we'll end up
             * missing the agents when we pull the local agents in init. This obviously would cause a catastrophic
             * failure if we don't have any agents registered.
             */
            pipeline.setContainerObject(this)
            pipeline.setParentInterface(this)
            pipeline.setP2pTransport(transport)
            pipeline.setP2pDescription(workerDescriptor)
            pipeline.setP2pRequirements(requirements)
            workerPipelinesByAgentName[resolvedAgentName] = pipeline

            /**
             * Register the worker pipeline with the P2PRegistry using generated settings.
             */
            P2PRegistry.register(pipeline, transport, workerDescriptor, requirements)
            return this
        }

        P2PRegistry.remove(pipeline) //Remove to ensure we aren't double registered.

        /**
         * Custom worker descriptors still need to remain local to this manifold so init() can discover them via the
         * registry before it activates worker pipelines.
         */
        pipeline.setContainerObject(this)
        pipeline.setParentInterface(this)
        pipeline.setP2pTransport(descriptor.transport)
        pipeline.setP2pDescription(descriptor)
        pipeline.setP2pRequirements(requirements)
        workerPipelinesByAgentName[descriptor.agentName] = pipeline

        /**
         * Register using assigned settings. None of them can be null otherwise we would not hit here.
         * So assume non-null and try to register.
         */
        P2PRegistry.register(pipeline, descriptor.transport, descriptor, requirements)
        return this
    }



    /**
     * Critical startup function for the Manifold class. This handles binding the agent list to all the pipes that
     * need it. This is especially important if the user remaps the default manager pipeline, or the worker pipelines.
     *
     * @throws Exception When manager pipeline has no pipes configured - prevents manifold from functioning
     * @throws Exception When no worker pipelines are registered - manifold requires workers to delegate tasks
     * @throws Exception When manager pipeline descriptor is null - required for P2P agent communication
     * @throws Exception When agent calling pipe cannot be found by name - breaks task delegation system
     */
    suspend fun init()
    {
        //Step 1: Check for empty pipelines. If any are empty we need to throw on the spot.
        if(managerPipeline.getPipes().isEmpty() || workerPipelines.isEmpty()) throw Exception("One or more manager or worker pipelines are empty. Cannot start the manifold.")

        //Bind our container to ensure our manifold manager is local. Init to ensure it's ready to make llm calls.
        managerPipeline.setContainerObject(this)
        managerPipeline.setParentInterface(this)
        
        // Setup tracing propagation to manager pipeline if enabled
        if(tracingEnabled)
        {
            managerPipeline.enableTracing(traceConfig)
            // Set currentPipelineId on individual pipes in the manager pipeline
            for(pipe in managerPipeline.getPipes())
            {
                pipe.currentPipelineId = manifoldId
            }
        }
        
        managerPipeline.init(true)

       //Fetch our descriptor so that we can build our agent descriptor.
        val managerDescriptor = managerPipeline.getP2pDescription() ?: throw Exception("Manager pipeline descriptor is null. Cannot start the manifold.")
        val managerAgentDescriptor = AgentDescriptor.buildFromDescriptor(managerDescriptor)

        val localAgents = P2PRegistry.listLocalAgents(this).toMutableList()
        localAgents.remove(managerDescriptor) //Remove manager so that we don't broadcast this to the workers.

        /**
         * All agents inside the manifold class need to be registered locally, since they will always be called
         * by the manager pipeline through local scope by default.
         */
        for(descriptor in localAgents)
        {
            val agentDescriptor = AgentDescriptor.buildFromDescriptor(descriptor)
            agentPaths.add(agentDescriptor)
        }

        /**
         * Dispatch the agent list to every manager pipe that needs to be able to call the worker pipelines/agents.
         */
        for(agentPipeName in agentPipeNames)
        {
            val agentCallingManagerPipe = managerPipeline.getPipeByName(agentPipeName)

            /**
             * If no pipe matches the expected names stored, we will find the very last pipe and assign that to
             * store the agent list. This is a fallback to ensure we don't break the manifold. Common setups including
             * the default setup from TPipe-Defaults uses the very last pipe as the agent calling pipe. So this
             * should safely adress most cases.
             *
             * todo: This behavior needs to be covered in the documentation for TPipe.
             */
            if(agentCallingManagerPipe.second == null)
            {
                managerPipeline.getPipes().last().setP2PAgentList(agentPaths)
                    .applySystemPrompt()
            }

            /**
             * Bind the descriptors to the agent calling pipe so that it is able to do its job and know which pipelines
             * in this manifold it can call.
             */
            agentCallingManagerPipe.second?.setP2PAgentList(agentPaths)
                ?.applySystemPrompt()
        }

        validateWorkerPipelineOverflowProtection()

        if(!autoTruncateContext && contextTruncationFunction == null)
        {
            throw Exception("No method of managing manager shared history was found. Configure Manifold manager budget control or supply a context truncation function.")
        }

        if(autoTruncateContext && resolveManagerBudgetConfiguration() == null)
        {
            throw Exception("Manager budget control is enabled, but no effective manager budget could be resolved.")
        }

        //Activate all the worker pipes to ensure they are ready to make llm calls.
        for(workerPipe in workerPipelines)
        {
            workerPipe.setContainerObject(this)
            workerPipe.setParentInterface(this)
            
            // Setup tracing propagation to worker pipelines if enabled
            if(tracingEnabled)
            {
                workerPipe.enableTracing(traceConfig)
                // Set currentPipelineId on individual pipes in the worker pipeline
                for(pipe in workerPipe.getPipes())
                {
                    pipe.currentPipelineId = manifoldId
                }
            }
            
            workerPipe.init(true)
        }

    }

//============================================= Budget Helpers =========================================================

    /**
     * Internal budget-resolution data used to drive manager shared-history truncation.
     *
     * @param budget Effective manager token budget after compatibility fallbacks are applied.
     * @param historyTokenBudget Token allotment available for shared converse history.
     */
    private data class ResolvedManagerBudget(
        val budget: TokenBudgetSettings,
        val historyTokenBudget: Int
    )

    /**
     * Resolve the first manager pipe because it is the pipe that consumes [workingContentObject] directly.
     *
     * @return First manager pipe, or null when the manager pipeline is empty.
     */
    private fun getPrimaryManagerPipe() : Pipe?
    {
        return managerPipeline.getPipes().firstOrNull()
    }

    /**
     * Resolve the manager budget that should govern the shared conversation history kept by this manifold.
     *
     * @return Effective manager budget and history space, or null when no built-in manager budgeting is configured.
     */
    private fun resolveManagerBudgetConfiguration() : ResolvedManagerBudget?
    {
        val managerPipe = getPrimaryManagerPipe() ?: return null
        val effectiveBudget = when
        {
            managerTokenBudget != null -> managerTokenBudget!!.deepCopy()
            managerPipe.copyTokenBudgetSettings() != null -> managerPipe.copyTokenBudgetSettings()!!.deepCopy()
            autoTruncateContext || managerContextWindowOverride != null -> {
                managerPipe.getTruncationSettings().toTokenBudgetSettings(
                    contextWindowSize = managerContextWindowOverride ?: managerPipe.getConfiguredContextWindowSize()
                )
            }
            else -> return null
        }

        val historyTokenBudget = estimateManagerHistoryTokenBudget(managerPipe, effectiveBudget)
        return ResolvedManagerBudget(effectiveBudget, historyTokenBudget)
    }

    /**
     * Estimate the token space available for the manager-facing shared conversation history after static reservations.
     *
     * @param managerPipe Primary manager pipe that consumes the shared history.
     * @param effectiveBudget Effective budget resolved for the manager.
     * @return Token space that can safely be used for shared manager history.
     */
    private fun estimateManagerHistoryTokenBudget(managerPipe: Pipe, effectiveBudget: TokenBudgetSettings) : Int
    {
        effectiveBudget.userPromptSize?.let { explicitUserPromptSize ->
            if(explicitUserPromptSize <= 0)
            {
                throw IllegalArgumentException("Manager token budget leaves no room for shared history because userPromptSize is $explicitUserPromptSize.")
            }
            return explicitUserPromptSize
        }

        val truncationSettings = effectiveBudget.toTruncationSettings(managerPipe)
        val systemPromptTokens = Dictionary.countTokens(managerPipe.getSystemPromptText(), truncationSettings)
        var availableHistoryBudget = effectiveBudget.contextWindowSize ?: managerPipe.getConfiguredContextWindowSize()
        availableHistoryBudget -= systemPromptTokens
        availableHistoryBudget -= effectiveBudget.maxTokens ?: managerPipe.getConfiguredMaxTokens()
        availableHistoryBudget -= effectiveBudget.reasoningBudget ?: 0

        if(availableHistoryBudget <= 0)
        {
            throw IllegalArgumentException(
                "Manager budget leaves no room for shared history after reserving output and system prompt tokens."
            )
        }

        return availableHistoryBudget
    }

    /**
     * Validate that every registered worker pipeline has a configured overflow-protection path.
     */
    private fun validateWorkerPipelineOverflowProtection()
    {
        val unprotectedWorkers = workerPipelines.filter { pipeline ->
            !pipeline.hasContextOverflowProtectionConfigured()
        }
        if(unprotectedWorkers.isEmpty())
        {
            return
        }

        val workerDescriptions = unprotectedWorkers.joinToString { pipeline ->
            val pipelineName = pipeline.pipelineName.ifEmpty { "<unnamed worker pipeline>" }
            val pipeNames = pipeline.getPipesWithoutContextOverflowProtection().joinToString { pipe ->
                pipe.pipeName.ifEmpty { "<unnamed pipe>" }
            }
            "$pipelineName [$pipeNames]"
        }
        throw Exception("Worker pipelines require token budgeting or auto truncation before Manifold execution: $workerDescriptions")
    }

    /**
     * Apply the built-in manager-history budget control to [workingContentObject] before the manager runs.
     */
    private fun applyBuiltInManagerBudgetControl()
    {
        val resolvedBudget = resolveManagerBudgetConfiguration() ?: return
        val converseHistory = extractJson<ConverseHistory>(workingContentObject.text) ?: return
        val truncationSettings = resolvedBudget.budget.toTruncationSettings(getPrimaryManagerPipe())
        val usedTokens = Dictionary.countTokens(serializeConverseHistory(converseHistory), truncationSettings)
        if(usedTokens <= resolvedBudget.historyTokenBudget)
        {
            return
        }

        val holdingWindow = ContextWindow()
        holdingWindow.converseHistory = converseHistory
        holdingWindow.truncateConverseHistoryWithObject(
            resolvedBudget.historyTokenBudget,
            0,
            truncationMethod,
            truncationSettings
        )
        workingContentObject.text = serializeConverseHistory(holdingWindow.converseHistory)
    }

    /**
     * Build the input MultimodalContent for the summary pipeline based on the current summary mode.
     *
     * APPEND mode: Input is the latest ConverseHistory entry content text only.
     * REGENERATE mode: Input is "Prior Summary:\n{runningSummary}\n\nLatest Event:\n{latestEventContent}"
     */
    private fun buildSummaryPipelineInput(): MultimodalContent
    {
        val converseHistory = extractJson<ConverseHistory>(workingContentObject.text)
        val latestEntry = converseHistory?.history?.lastOrNull()
        val latestText = latestEntry?.content?.text ?: ""

        val inputText = when (summaryMode)
        {
            SummaryMode.APPEND -> latestText
            SummaryMode.REGENERATE -> buildString {
                if (runningSummary.isNotEmpty())
                {
                    append("Prior Summary:\n")
                    append(runningSummary)
                    append("\n\n")
                }
                append("Latest Event:\n")
                append(latestText)
            }
        }

        return MultimodalContent(inputText).apply {
            metadata = workingContentObject.metadata.toMutableMap()  // preserve source metadata
        }
    }

//=================================================Execution============================================================

    /**
     * Executes the manifold orchestration system, coordinating between manager and worker pipelines
     * to complete complex tasks through agent delegation and task management.
     *
     * @param content The initial task content to be processed by the manifold system
     * @return The final processed content after all agent interactions are complete
     * @throws Exception When converse history extraction fails - required for tracking agent interactions
     */
    suspend fun execute(content: MultimodalContent) : MultimodalContent
    {
        /**
         * Throw if our manager pipeline does not have agents assigned. In this event we would have a silent but
         * likely catastrophic failure. So we need to throw here.
         */
        hasP2P(managerPipeline)

        // Initialize kill switch tracking for this execution
        if(killSwitch != null)
        {
            killSwitchExecutionStartTime = System.currentTimeMillis()
            killSwitchInputAccumulator = 0
            killSwitchOutputAccumulator = 0
        }

        // Save the initial user prompt for developer use in manager pipelines
        initialUserPrompt = content.text

        // === TRACING: Initialize execution tracing ===
        if(tracingEnabled)
        {
            PipeTracer.startTrace(manifoldId)
            trace(TraceEventType.MANIFOLD_START, TracePhase.ORCHESTRATION, content,
                  metadata = mapOf(
                      "inputContentSize" to content.text.length,
                      "hasBinaryContent" to content.binaryContent.isNotEmpty()
                  ))
        }

        //We can skip this if the data is already formated in the required converse history format.
        val isConverseHistory = extractJson<ConverseHistory>(content.text)
        if(isConverseHistory == null)
        {
            // === TRACING: Converse history creation ===
            if(tracingEnabled)
            {
                trace(TraceEventType.CONVERSE_HISTORY_UPDATE, TracePhase.ORCHESTRATION,
                      metadata = mapOf("action" to "createInitialHistory"))
            }
            
            /**
             * We need to build an initial converse starter because the manager pipeline is expected converse by default.
             * This is also the intended use case to structure a custom manager pipeline if the default were to be
             * overridden. By using TPipe's converse system, we're able to ensure optimal tracking of the task
             * and the history of events that have occurred to attempt to resolve the task.
             */
            val newConverseHistory = ConverseHistory()
            newConverseHistory.add(ConverseRole.user, content)

            val converseHistoryAsJson = serializeConverseHistory(newConverseHistory)
            content.text = converseHistoryAsJson
            workingContentObject = MultimodalContent(
                text = content.text,
                binaryContent = content.binaryContent.toMutableList(),
                terminatePipeline = content.terminatePipeline
            ).apply {
                metadata = content.metadata.toMutableMap()
            }
        }

        //If we're skipping, we can push directly to the text portion of the object which forms our user prompt space.
        else
        {
            workingContentObject = MultimodalContent(
                text = content.text,
                binaryContent = content.binaryContent.toMutableList(),
                terminatePipeline = content.terminatePipeline
            ).apply {
                metadata = content.metadata.toMutableMap()
            }
        }

        // === DITL: Run manifold init function if configured ===
        if(manifoldInitFunctionRef != null)
        {
            if(tracingEnabled)
            {
                trace(TraceEventType.MANIFOLD_INIT_CHECK, TracePhase.ORCHESTRATION,
                      workingContentObject,
                      metadata = mapOf("result" to "running"))
            }

            if(manifoldInitFunctionRef?.invoke(workingContentObject, this) == false)
            {
                if(tracingEnabled)
                {
                    trace(TraceEventType.MANIFOLD_INIT_CHECK, TracePhase.ORCHESTRATION,
                          workingContentObject,
                          metadata = mapOf("result" to "abort", "reason" to "initFunction returned false"))
                }
                return workingContentObject
            }

            if(tracingEnabled)
            {
                trace(TraceEventType.MANIFOLD_INIT_CHECK, TracePhase.ORCHESTRATION,
                      workingContentObject,
                      metadata = mapOf("result" to "proceed"))
            }
        }

        // === TRACING: Reset loop counter ===
        loopIterationCount = 0

        /**
         * Execution will continue in this sequence as long as a terminate call or pass flag has not been set
         * in the content object. If you're using a custom manager pipeline, it's mission-critical that you validate
         * if the llm has decided the job is done and end the pipeline with a pass call. Otherwise, the manifold will
         * never terminate and the llm will loop in this pattern forever.
         */
        while(!workingContentObject.terminatePipeline && !workingContentObject.passPipeline)
        {
            // Loop limit check BEFORE incrementing iteration counter
            if(maxLoopIterations != null && loopIterationCount >= maxLoopIterations!!)
            {
                if(tracingEnabled)
                {
                    trace(TraceEventType.MANIFOLD_LOOP_LIMIT_EXCEEDED, TracePhase.ERROR,
                          metadata = mapOf(
                              "iterationsReached" to loopIterationCount,
                              "maxIterations" to maxLoopIterations!!
                          ))
                }
                throw ManifoldLoopLimitExceededException(
                    iterationsReached = loopIterationCount,
                    maxIterations = maxLoopIterations!!,
                    context = null
                )
            }

            // === TRACING: Loop iteration tracking ===
            loopIterationCount++
            if(tracingEnabled)
            {
                trace(TraceEventType.MANIFOLD_LOOP_ITERATION, TracePhase.ORCHESTRATION,
                      metadata = mapOf(
                          "iteration" to loopIterationCount,
                          "loopLimit" to (maxLoopIterations ?: "none"),
                          "terminateFlag" to workingContentObject.terminatePipeline,
                          "passFlag" to workingContentObject.passPipeline
                      ))
            }

            //Step 1: Execute the manager pipeline and get the initial result of its actions.
            // === TRACING: Manager task analysis ===
            if(tracingEnabled)
            {
                trace(TraceEventType.MANAGER_TASK_ANALYSIS, TracePhase.ORCHESTRATION,
                      workingContentObject,
                      metadata = mapOf("managerPipeline" to managerPipeline.pipelineName))
            }

            if(contextTruncationFunction != null)
            {
                contextTruncationFunction?.invoke(workingContentObject)
            }

            else if(autoTruncateContext)
            {
                applyBuiltInManagerBudgetControl()
            }

            //Get the result of the manager pipeline's execution and assessment of task status.
            // Kill switch check before manager execution
            if(killSwitch != null)
            {
                val elapsedMs = System.currentTimeMillis() - killSwitchExecutionStartTime
                checkKillSwitch(killSwitchInputAccumulator, killSwitchOutputAccumulator, elapsedMs)
            }
            val managerResult = managerPipeline.execute(workingContentObject)

            // Accumulate manager tokens and check kill switch after execution
            if(killSwitch != null)
            {
                killSwitchInputAccumulator += managerPipeline.inputTokensSpent
                killSwitchOutputAccumulator += managerPipeline.outputTokensSpent
                val elapsedMs = System.currentTimeMillis() - killSwitchExecutionStartTime
                checkKillSwitch(killSwitchInputAccumulator, killSwitchOutputAccumulator, elapsedMs)
            }

            // === TRACING: Manager decision ===
            if(tracingEnabled)
            {
                trace(TraceEventType.MANAGER_DECISION, TracePhase.ORCHESTRATION, managerResult,
                      metadata = mapOf(
                          "responseLength" to managerResult.text.length,
                          "iteration" to loopIterationCount
                      ))
            }

            // NEW: Check if the manager pipeline has indicated task completion
            // Extract TaskProgress from the ConverseHistory in workingContentObject.text
            val currentConverseHistory = extractJson<ConverseHistory>(workingContentObject.text)
            val latestTaskProgressJson = currentConverseHistory?.history?.lastOrNull { it.role == ConverseRole.system }?.content?.text
            val taskProgress = latestTaskProgressJson?.let { extractJson<TaskProgress>(it) }

            if(taskProgress != null && taskProgress.isTaskComplete)
            {
                workingContentObject.passPipeline = true
                // === TRACING: Manifold completion signaled by manager ===
                if(tracingEnabled)
                {
                    trace(TraceEventType.MANIFOLD_SUCCESS, TracePhase.CLEANUP, managerResult,
                          metadata = mapOf("reason" to "Manager signaled task completion"))
                }
                break // Exit the manifold loop gracefully
            }

            /**
             * Execute validation function if bound. This allows the human to check to see if the llm has broken
             * or otherwise, done something unacceptable. In that case, the issue can be attempted to be repaired,
             * and if we cannot repair it, we'll exit the manifold task to avoid harmful content, or actions
             * that could cause damage to the codebase, system, application, or end user.
             *
             * If not provided this check will be skipped and passed forward regardless of what the outcome was.
             */
            if(workerValidatorFunction != null)
            {
                trace(TraceEventType.VALIDATION_START, TracePhase.ORCHESTRATION,
                    metadata = mapOf("validatorFunction" to workerValidatorFunction.toString()))

                //Handle branch failure state if our validation function did not pass.
                if(workerValidatorFunction?.invoke(managerResult, managerPipeline, this) == false)
                {
                    //Execute branch failure if provided. This gives one last change to not end the manifold.
                    if(failureFunction != null)
                    {
                        trace(TraceEventType.VALIDATION_FAILURE, TracePhase.ORCHESTRATION,
                            metadata = mapOf("failureFunction" to failureFunction.toString()))

                        //Bail on the manifold if we can't pass this. Otherwise, we can resume the task.
                        if(failureFunction?.invoke(managerResult, managerPipeline, this) == false)
                        {
                            /**
                             * Optional: Allow provision of error message by using the multimodal object's metadata
                             * map which allows for any arbitrary data to be stored.
                             *
                             * todo: We should add this to the regular pipe class too.
                             */
                            val errorMessage = managerResult.metadata["error"] ?: "Unable to recover using branch failure function."

                            trace(TraceEventType.PIPE_FAILURE, TracePhase.ORCHESTRATION,
                                metadata = mapOf("failureFunction" to failureFunction.toString(),
                                    "reason" to errorMessage.toString()))

                            workingContentObject.terminate()
                            break
                        }

                    }

                    //No branch failure provided, but we were not able to proceed through the validator.
                    else
                    {
                        workingContentObject.terminate()
                        break
                    }
                }
            }



            //Get our response text which should hold our target p2p call.
            val responseText = managerResult.text

            /**
             * Determine if our task is finished. If so we need to now exit with the final result of our
             * working content object. If the task checker marked this as complete the rest of the pipeline should
             * have been passed or terminated resulting in only it's output being the last output produced.
             */
            val taskStatusCheck = extractJson<TaskProgress>(responseText)
            if(taskStatusCheck != null)
            {
                if(taskStatusCheck.isTaskComplete)
                {
                    trace(TraceEventType.MANIFOLD_SUCCESS, TracePhase.CLEANUP,
                        metadata = mapOf("taskStatus" to "task complete"))
                    return workingContentObject
                }
            }

            /**
             * We're expecting that the result should always be an agent request. If it isn't we have to terminate
             * in a broken state and exit. It's not entirely impossible that a poorly formatted system prompt or
             * misbehaving llm might not produce the json as intended, or correctly. And in that case could prevent
             * the manifold from continuing.
             */
            var agentBatchCount = 0 //Attempt to extract out of an array if an array was returned.
            var agentRequest = extractJson<List<AgentRequest>>(responseText)?.let { list ->
                agentBatchCount = list.size
                list.firstOrNull()
            }

            //Otherwise try to grab it from the string as a whole.
            if(agentRequest == null)
            {
                agentRequest = extractJson<AgentRequest>(responseText)
            }

            // === TRACING: Agent request extraction (diagnostic - shows if LLM produced JSON vs extraction failure) ===
            if(tracingEnabled)
            {
                trace(TraceEventType.AGENT_REQUEST_EXTRACTION, TracePhase.ORCHESTRATION,
                      metadata = mapOf(
                          "extractedAgentName" to (agentRequest?.agentName ?: "NULL"),
                          "responseLength" to responseText.length,
                          "responsePreview" to responseText.take(300),
                          "extractionSource" to if(agentBatchCount > 0) "list-first" else "direct",
                          "iteration" to loopIterationCount
                      ))
            }

            /**
             * Manager pipelines tend to try to issue pcp requests. However, the manifold manager pipeline is only
             * allowed to issue p2p requests. So to save tokens we should get rid of any random pcp requests it
             * tries to make. This behavior happens because we provide pcp data to help guide decision-making for
             * the manager pipeline to choose the best agent for the next task. Unfortunately we often run into
             * issues where some llm's don't quite get the memo and produce pcp tool calls anyways.
             */
            if(agentRequest != null && agentRequest.pcpRequest != PcPRequest())
            {
                agentRequest.pcpRequest = PcPRequest()
                if(tracingEnabled)
                {
                    trace(TraceEventType.AGENT_REQUEST_INVALID, TracePhase.ORCHESTRATION,
                          metadata = mapOf("reason" to "pcpRequest reset to empty PcPRequest",
                                           "agentName" to agentRequest.agentName))
                }
            }

            //Kill with an error if we didn't get a valid agent request as the final output.
            if(agentRequest == null)
            {
                // === TRACING: Invalid agent request ===
                if(tracingEnabled)
                {
                    trace(TraceEventType.AGENT_REQUEST_INVALID, TracePhase.ORCHESTRATION,
                          managerResult,
                          error = Exception("Invalid agent request format"),
                          metadata = mapOf(
                              "responseText" to responseText.take(200),
                              "iteration" to loopIterationCount
                          ))
                }

                workingContentObject.terminatePipeline = true
                break
            }

            // === TRACING: Valid agent request ===
            if(tracingEnabled)
            {
                trace(TraceEventType.AGENT_REQUEST_VALIDATION, TracePhase.ORCHESTRATION,
                      metadata = mapOf(
                          "agentName" to agentRequest.agentName,
                          "requestValid" to true,
                          "requestSource" to if(agentBatchCount > 0) "array" else "object",
                          "batchSize" to if(agentBatchCount > 0) agentBatchCount else 1,
                          "iteration" to loopIterationCount
                      ))
            }

            /**
             * Grab the converse history from the content object if it exists so that we can record this action
             * that the manager pipeline took. This is important since the manager pipeline needs to be able to
             * track both what it decided to do next, and what each agent did as the manifold works through
             * the task at large.
             */
            val previousConverseHistory = extractJson<ConverseHistory>(workingContentObject.text)
            if(previousConverseHistory != null)
            {
                previousConverseHistory.add(ConverseRole.system, managerResult)
                workingContentObject.text = serializeConverseHistory(previousConverseHistory)
                
                // === TRACING: Converse history update ===
                if(tracingEnabled)
                {
                    trace(TraceEventType.CONVERSE_HISTORY_UPDATE, TracePhase.ORCHESTRATION,
                          metadata = mapOf(
                              "action" to "addManagerDecision",
                              "historySize" to previousConverseHistory.history.size
                          ))
                }
            }

                /**
                 * Try to invoke the agent the manager pipeline is trying to call. If we can, then we can proceed.
                 * Otherwise, we can't continue the Manifold.
                 *
                 * todo: Should we consider a retry option in the event that the llm is misbehaving? Or should we place
                 * the full onus on the coder to ensure the llm actually produces json and they didn't mess up their
                * system prompt?
                */
            try{
                // === TRACING: Agent interaction tracking ===
                agentInteractionMap[agentRequest.agentName] = 
                    agentInteractionMap.getOrDefault(agentRequest.agentName, 0) + 1

                if(tracingEnabled)
                {
                    trace(TraceEventType.AGENT_DISPATCH, TracePhase.AGENT_COMMUNICATION,
                          metadata = mapOf(
                              "agentName" to agentRequest.agentName,
                              "interactionCount" to (agentInteractionMap[agentRequest.agentName] as Any),
                              "iteration" to (loopIterationCount as Any)
                          ))
                }

                /**
                 * Invoke the agent request system which will route and reach the local agent we have here.
                 * That agent will run through its task set as a pipeline, and return the result. Converse gets
                 * wrapped up here and passed as the input of the worker pipeline, apparently regardless of what it's
                 * json input is set to.
                 */
                val workerConverseHistory = extractJson<ConverseHistory>(workingContentObject.text)
                if(workerConverseHistory != null)
                {
                    agentRequest.prompt = ""
                    agentRequest.content = serializeConverseHistory(workerConverseHistory)
                    agentRequest.promptSchema = InputSchema.json
                }

                // Kill switch check before worker dispatch
                if(killSwitch != null)
                {
                    val elapsedMs = System.currentTimeMillis() - killSwitchExecutionStartTime
                    checkKillSwitch(killSwitchInputAccumulator, killSwitchOutputAccumulator, elapsedMs)
                }

                val response = P2PRegistry.sendP2pRequest(
                    agentRequest,
                    returnAddressOverride = managerPipeline.getP2pTransport()
                )

                // Accumulate worker tokens after execution
                if(killSwitch != null)
                {
                    val workerPipeline = workerPipelinesByAgentName[agentRequest.agentName] ?: workerPipelines.find { pipeline ->
                        pipeline.getP2pDescription()?.agentName == agentRequest.agentName ||
                            pipeline.getP2pTransport()?.transportAddress == agentRequest.agentName
                    }
                    if(workerPipeline != null)
                    {
                        killSwitchInputAccumulator += workerPipeline.inputTokensSpent
                        killSwitchOutputAccumulator += workerPipeline.outputTokensSpent
                    }
                    val elapsedMs = System.currentTimeMillis() - killSwitchExecutionStartTime
                    checkKillSwitch(killSwitchInputAccumulator, killSwitchOutputAccumulator, elapsedMs)
                }

                //In the event a rejection occurs we'll need to exit the manifold.
                val rejection = response.rejection

                if(rejection != null)
                {
                    // === TRACING: P2P request rejection ===
                    if(tracingEnabled)
                    {
                        trace(TraceEventType.P2P_REQUEST_FAILURE, TracePhase.AGENT_COMMUNICATION,
                              error = Exception("P2P request rejected: $rejection"),
                              metadata = mapOf(
                                  "agentName" to agentRequest.agentName,
                                  "rejection" to rejection,
                                  "iteration" to loopIterationCount
                              ))
                    }
                    workingContentObject.terminatePipeline = true
                    break
                }

                // === TRACING: Successful agent response ===
                if(tracingEnabled)
                {
                    trace(TraceEventType.AGENT_RESPONSE, TracePhase.AGENT_COMMUNICATION,
                          response.output,
                          metadata = mapOf(
                              "agentName" to agentRequest.agentName,
                              "responseLength" to (response.output?.text?.length ?: 0),
                              "hasBinaryContent" to (response.output?.binaryContent?.isNotEmpty() ?: false),
                              "iteration" to loopIterationCount
                          ))
                }

                /**
                 * Agent ran as intended and produced a result. Now we need to build all this into a proper converse
                 * history and push it back. Then allow the while loop to continue.
                 */
                val output = response.output?.text ?: ""
                val converseHistory = extractJson<ConverseHistory>(workingContentObject.text) ?: throw Exception("Converse history is null. Cannot extract manifold agent's response.")


                /**
                 * Final human in the loop steps for this while loop. Runs the bound validation function if present, branches
                 * to failure if required, and then finally invokes the transformation function.
                 *
                 *
                 * Execute validation function if bound for worker pipeline response. This allows the human to check 
                 * if the worker agent has broken or produced unacceptable output. The issue can be attempted to be 
                 * repaired, and if we cannot repair it, we'll exit the manifold task.
                 */
                if(workerValidatorFunction != null)
                {
                    trace(TraceEventType.VALIDATION_START, TracePhase.ORCHESTRATION,
                        metadata = mapOf("validatorFunction" to workerValidatorFunction.toString()))

                    //Get the worker pipeline that just executed
                    val workerPipeline = workerPipelinesByAgentName[agentRequest.agentName] ?: workerPipelines.find { pipeline ->
                        pipeline.getP2pDescription()?.agentName == agentRequest.agentName ||
                            pipeline.getP2pTransport()?.transportAddress == agentRequest.agentName
                    }

                    //Handle branch failure state if our validation function did not pass.
                    if(workerPipeline != null && workerValidatorFunction?.invoke(response.output!!, workerPipeline, this) == false)
                    {
                        //Execute branch failure if provided. This gives one last chance to not end the manifold.
                        if(failureFunction != null)
                        {
                            trace(TraceEventType.VALIDATION_FAILURE, TracePhase.ORCHESTRATION,
                                metadata = mapOf("failureFunction" to failureFunction.toString()))

                            //Bail on the manifold if we can't pass this. Otherwise, we can resume the task.
                            if(failureFunction?.invoke(response.output!!, workerPipeline, this) == false)
                            {
                                val errorMessage = response.output?.metadata?.get("error") ?: "Unable to recover using branch failure function."

                                trace(TraceEventType.PIPE_FAILURE, TracePhase.ORCHESTRATION,
                                    metadata = mapOf("failureFunction" to failureFunction.toString(),
                                        "reason" to errorMessage.toString()))

                                workingContentObject.terminate()
                                break
                            }
                        }

                        //No branch failure provided, but we were not able to proceed through the validator.
                        else
                        {
                            workingContentObject.terminate()
                            break
                        }
                    }
                }

                /**
                 * Execute transformation function if bound. This allows for content transformation upon a 
                 * successful worker agent call and can be used to execute any pcp tools.
                 */
                if(transformationFunction != null)
                {
                    trace(TraceEventType.TRANSFORMATION_START, TracePhase.ORCHESTRATION,
                        response.output,
                        metadata = mapOf("inputText" to (response.output?.text ?: "")))
                    
                    response.output = transformationFunction?.invoke(response.output!!) ?: response.output
                    
                    trace(TraceEventType.TRANSFORMATION_SUCCESS, TracePhase.ORCHESTRATION,
                        response.output,
                        metadata = mapOf("outputText" to (response.output?.text ?: "")))
                }


                //Update the converse history with the agent's response.
                try {
                    converseHistory?.add(ConverseRole.agent, response.output!!)
                    
                    // === TRACING: Agent response added to history ===
                    if(tracingEnabled)
                    {
                        trace(TraceEventType.CONVERSE_HISTORY_UPDATE, TracePhase.ORCHESTRATION,
                              metadata = mapOf(
                                  "action" to "addAgentResponse",
                                  "agentName" to agentRequest.agentName,
                                  "historySize" to converseHistory.history.size
                              ))
                    }
                }
                catch(e: com.TTT.P2P.KillSwitchException)
                {
                    // KillSwitchException must never be caught — it must propagate to terminate the agent
                    throw e
                }
                catch(e: Exception)
                {
                    // === TRACING: Converse history update failure ===
                    if(tracingEnabled)
                    {
                        trace(TraceEventType.MANIFOLD_FAILURE, TracePhase.ORCHESTRATION,
                              error = e,
                              metadata = mapOf(
                                  "failurePoint" to "converseHistoryUpdate",
                                  "agentName" to agentRequest.agentName
                              ))
                    }
                    workingContentObject.terminatePipeline = true
                    break
                }

                //Push agent's response back to the converse history and working content object.
                workingContentObject.text = serializeConverseHistory(converseHistory)

                /**
                 * Next, it's very important that we now wipe the text of the response so that we can safely merge
                 * the contents of the response into our working content object. This ensures we push back
                 * anything like binary and non text data back in one go correctly.
                 */
                try {
                    response.output?.text = ""
                    workingContentObject.merge(response.output!!)
                    
                    // === TRACING: Content merge successful ===
                    if(tracingEnabled)
                    {
                        trace(TraceEventType.AGENT_RESPONSE_PROCESSING, TracePhase.ORCHESTRATION,
                              workingContentObject,
                              metadata = mapOf(
                                  "agentName" to agentRequest.agentName,
                                  "mergeSuccessful" to true,
                                  "finalContentSize" to workingContentObject.text.length
                              ))
                    }
                }
                catch(e: com.TTT.P2P.KillSwitchException)
                {
                    // KillSwitchException must never be caught — it must propagate to terminate the agent
                    throw e
                }
                catch(e: Exception)
                {
                    // === TRACING: Content merge failure ===
                    if(tracingEnabled)
                    {
                        trace(TraceEventType.MANIFOLD_FAILURE, TracePhase.ORCHESTRATION,
                              error = e,
                              metadata = mapOf(
                                  "failurePoint" to "contentMerge",
                                  "agentName" to agentRequest.agentName
                              ))
                    }
                    workingContentObject.terminatePipeline = true
                    break
                }

            }
            catch(e: com.TTT.P2P.KillSwitchException)
            {
                // KillSwitchException must never be caught — it must propagate to terminate the agent
                throw e
            }
            catch(e: Exception)
            {
                // === TRACING: P2P communication failure ===
                if(tracingEnabled)
                {
                    trace(TraceEventType.P2P_COMMUNICATION_FAILURE, TracePhase.AGENT_COMMUNICATION,
                          error = e,
                          metadata = mapOf(
                              "agentName" to agentRequest.agentName,
                              "errorType" to (e::class.simpleName ?: "Unknown"),
                              "iteration" to (loopIterationCount as Any)
                          ))
                }
                workingContentObject.terminatePipeline = true; break
            }

            // === NEW: Summary Pipeline invocation ===
            if (summaryPipeline != null)
            {
                val summaryInput = buildSummaryPipelineInput()
                val summaryResult = summaryPipeline!!.execute(summaryInput)
                val summaryText = summaryResult.text.ifEmpty {
                    summaryResult.metadata["summary"]?.toString() ?: ""
                }

                if (summaryText.isNotEmpty())
                {
                    when (summaryMode)
                    {
                        SummaryMode.APPEND -> runningSummary += summaryText
                        SummaryMode.REGENERATE -> runningSummary = summaryText
                    }
                }
            }
            // ==========================================

            // === TRACING: Termination condition check ===
            if(tracingEnabled)
            {
                trace(TraceEventType.MANIFOLD_TERMINATION_CHECK, TracePhase.ORCHESTRATION,
                      metadata = mapOf(
                          "terminateFlag" to workingContentObject.terminatePipeline,
                          "passFlag" to workingContentObject.passPipeline,
                          "iteration" to loopIterationCount
                      ))
            }



        }

        // === TRACING: Final execution result ===
        if(tracingEnabled)
        {
            val finalEventType = if(workingContentObject.terminatePipeline) {
                TraceEventType.MANIFOLD_FAILURE
            }
            else
            {
                TraceEventType.MANIFOLD_SUCCESS
            }
            
            trace(finalEventType, TracePhase.CLEANUP, workingContentObject,
                  metadata = mapOf(
                      "totalIterations" to (loopIterationCount as Any),
                      "finalContentSize" to workingContentObject.text.length,
                      "agentInteractions" to agentInteractionMap.size
                  ))
            
            trace(TraceEventType.MANIFOLD_END, TracePhase.CLEANUP, workingContentObject)
        }

        return workingContentObject
    }

    /**
     * Pause the thread running the manifold to stop it from proceeding forward. This should be used carefully and
     * called as part of the transformation function of a worker pipe to avoid llm stalls.
     */
    suspend fun pause()
    {
        isPaused = true
        resumeSignal.receive()
        isPaused = false
    }

    /**
     * Resumes the manifold. This will cause the while loop to proceed and the manifold manager to worker feedback loop
     * to fully resume.
     */
    suspend fun resume()
    {
        resumeSignal.trySend(Unit)
    }

//==============================================Tracing Methods========================================================

    /**
     * Enables tracing for this Manifold with the specified configuration.
     * Propagates tracing settings to all child pipelines and P2P components.
     * 
     * @param config The tracing configuration to use
     * @return This Manifold object for method chaining
     */
    fun enableTracing(config: TraceConfig = TraceConfig(enabled = true)): Manifold
    {
        this.tracingEnabled = true
        this.traceConfig = config
        PipeTracer.enable() // Enable global tracer
        return this
    }

    /**
     * Disables tracing for this Manifold and all child components.
     * 
     * @return This Manifold object for method chaining
     */
    fun disableTracing(): Manifold
    {
        this.tracingEnabled = false
        return this
    }

    /**
     * Internal tracing method following same pattern as Pipe class.
     * Handles verbosity filtering and metadata building for Manifold events.
     * 
     * @param eventType The type of event being traced
     * @param phase The execution phase context
     * @param content Optional multimodal content to include
     * @param metadata Additional event metadata
     * @param error Optional exception details
     */
    private fun trace(
        eventType: TraceEventType,
        phase: TracePhase,
        content: MultimodalContent? = null,
        metadata: Map<String, Any> = emptyMap(),
        error: Throwable? = null
    )
    {
        if(!tracingEnabled) return
        
        // Verbosity filtering using existing EventPriorityMapper
        if(!EventPriorityMapper.shouldTrace(eventType, traceConfig.detailLevel)) return
        
        // Build enhanced metadata based on verbosity level
        val enhancedMetadata = buildManifoldMetadata(metadata, traceConfig.detailLevel, eventType, error)
        
        // Create event with conditional content inclusion
        val event = TraceEvent(
            timestamp = System.currentTimeMillis(),
            pipeId = manifoldId,
            pipeName = "Manifold-${managerPipeline.pipelineName}",
            eventType = eventType,
            phase = phase,
            content = if(shouldIncludeContent(traceConfig.detailLevel)) content else null,
            contextSnapshot = if(shouldIncludeContext(traceConfig.detailLevel)) managerPipeline.context else null,
            metadata = if(traceConfig.includeMetadata) enhancedMetadata else emptyMap(),
            error = error
        )
        
        // Submit to central tracer using manifold ID
        PipeTracer.addEvent(manifoldId, event)
    }

    /**
     * Builds Manifold-specific metadata based on verbosity level.
     * Follows same pattern as Pipe.buildMetadataForLevel() method.
     * 
     * @param baseMetadata Base metadata to enhance
     * @param detailLevel Current verbosity level
     * @param eventType Type of event being traced
     * @param error Optional error information
     * @return Enhanced metadata map
     */
    private fun buildManifoldMetadata(
        baseMetadata: Map<String, Any>,
        detailLevel: TraceDetailLevel,
        eventType: TraceEventType,
        error: Throwable?
    ): Map<String, Any>
    {
        val metadata = baseMetadata.toMutableMap()
        
        when(detailLevel)
        {
            TraceDetailLevel.MINIMAL ->
            {
                if(error != null)
                {
                    metadata["error"] = error.message ?: "Unknown error"
                }
            }
            
            TraceDetailLevel.NORMAL ->
            {
                metadata["manifoldId"] = manifoldId
                metadata["managerPipeline"] = managerPipeline.pipelineName
                metadata["workerCount"] = workerPipelines.size
                metadata["loopIteration"] = loopIterationCount
                if(error != null)
                {
                    metadata["error"] = error.message ?: "Unknown error"
                    metadata["errorType"] = error::class.simpleName ?: "Unknown"
                }
            }
            
            TraceDetailLevel.VERBOSE ->
            {
                metadata["manifoldClass"] = this::class.qualifiedName ?: "Manifold"
                metadata["manifoldId"] = manifoldId
                metadata["managerPipeline"] = managerPipeline.pipelineName
                metadata["workerPipelines"] = workerPipelines.map { it.pipelineName }
                metadata["agentPaths"] = agentPaths.map { it.agentName }
                metadata["loopIteration"] = loopIterationCount
                metadata["taskComplete"] = currentTaskProgress.isTaskComplete
                metadata["taskProgress"] = currentTaskProgress.taskProgressStatus
                metadata["agentInteractions"] = agentInteractionMap.size
                if(error != null)
                {
                    metadata["error"] = error.message ?: "Unknown error"
                    metadata["errorType"] = error::class.simpleName ?: "Unknown"
                }
            }
            
            TraceDetailLevel.DEBUG ->
            {
                // Everything from VERBOSE plus detailed debug information
                metadata["manifoldClass"] = this::class.qualifiedName ?: "Manifold"
                metadata["manifoldId"] = manifoldId
                metadata["managerPipeline"] = managerPipeline.pipelineName
                metadata["workerPipelines"] = workerPipelines.map { it.pipelineName }
                metadata["agentPaths"] = agentPaths.map { "${it.agentName}:${it.description}" }
                metadata["agentPipeNames"] = agentPipeNames
                metadata["loopIteration"] = loopIterationCount
                metadata["taskComplete"] = currentTaskProgress.isTaskComplete
                metadata["taskProgress"] = currentTaskProgress.taskProgressStatus
                metadata["nextTaskInstructions"] = currentTaskProgress.nextTaskInstructions
                metadata["agentInteractionMap"] = agentInteractionMap
                metadata["workingContentSize"] = workingContentObject.text.length
                metadata["p2pDescriptor"] = p2pDescriptor?.agentName ?: "null"
                if(error != null)
                {
                    metadata["error"] = error.message ?: "Unknown error"
                    metadata["errorType"] = error::class.simpleName ?: "Unknown"
                    metadata["stackTrace"] = error.stackTraceToString()
                }
            }
        }
        
        return metadata
    }

    /**
     * Determines if content should be included based on verbosity level.
     * Follows same logic as Pipe class for consistency.
     * 
     * @param detailLevel Current verbosity level
     * @return True if content should be included
     */
    private fun shouldIncludeContent(detailLevel: TraceDetailLevel): Boolean
    {
        return when(detailLevel)
        {
            TraceDetailLevel.MINIMAL -> false
            TraceDetailLevel.NORMAL -> false
            TraceDetailLevel.VERBOSE -> traceConfig.includeContext
            TraceDetailLevel.DEBUG -> traceConfig.includeContext
        }
    }

    /**
     * Determines if context should be included based on verbosity level.
     * Follows same logic as Pipe class for consistency.
     * 
     * @param detailLevel Current verbosity level
     * @return True if context should be included
     */
    private fun shouldIncludeContext(detailLevel: TraceDetailLevel): Boolean
    {
        return when(detailLevel)
        {
            TraceDetailLevel.MINIMAL -> false
            TraceDetailLevel.NORMAL -> false
            TraceDetailLevel.VERBOSE -> traceConfig.includeContext
            TraceDetailLevel.DEBUG -> traceConfig.includeContext
        }
    }

    /**
     * Gets trace report for this Manifold in the specified format.
     * 
     * @param format Output format (defaults to config setting)
     * @return Formatted trace report string
     */
    fun getTraceReport(format: TraceFormat = traceConfig.outputFormat): String
    {
        return PipeTracer.exportTrace(manifoldId, format)
    }

    /**
     * Gets failure analysis for this Manifold if tracing is enabled.
     * 
     * @return FailureAnalysis object or null if tracing is disabled
     */
    fun getFailureAnalysis(): FailureAnalysis?
    {
        return if(tracingEnabled) PipeTracer.getFailureAnalysis(manifoldId) else null
    }

    /**
     * Gets the unique trace ID for this Manifold.
     * 
     * @return Manifold trace ID string
     */
    fun getTraceId(): String = manifoldId


//=================================================Builders=============================================================

    /**
     * Builder that constructs a solid default pipeline already configured to act as a manager for the worker pipes
     * provides a solid set of instructions to cover most general cases that would need a manifold without asking the
     * user to build their own pipeline from scratch.
     *
     * @param provider The provider name of the llm to use
     * @param model The model name of the llm to use
     */
    fun buildDefaultManagerPipeline(provider: ProviderName, model: String, region: String = "", url: String = "", port: Int = 0)
    {
        var newManagerPipeline = Pipeline()


    }

}
