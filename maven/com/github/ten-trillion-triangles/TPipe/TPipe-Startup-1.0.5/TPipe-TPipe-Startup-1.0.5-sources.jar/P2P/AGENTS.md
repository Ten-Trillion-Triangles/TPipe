# P2P Module

## OVERVIEW
Distributed agent communication layer — P2PRegistry handles routing/auth, P2PHostedRegistry manages hosted agent discovery, and P2PInterface is implemented by all Pipeline containers.

## STRUCTURE
```
P2P/
├── P2PInterface.kt        # Contract for P2P communication (all Pipeline containers implement)
├── P2PRegistry.kt         # Agent routing, auth gating, request templates (1,423 LOC)
├── P2PHostedRegistry.kt   # Hosted agent registry, policy hooks, audit (2,128 LOC)
├── P2PHost.kt             # STDIO/stdin host handler for incoming requests
├── P2PRequest.kt          # P2PRequest with transport, prompt, context, custom schemas
├── P2PResponse.kt         # P2PResponse, P2PRejection, P2PError enum (auth/prompt/transport/etc)
├── P2PDescriptor.kt       # Agent advertisement with transport config
├── P2PRequirements.kt     # Agent security/strictness requirements
├── P2PHostedRegistryModels.kt  # Listing kinds: AGENT, GRID_NODE, GRID_REGISTRY
├── P2PHostedRegistryTools.kt  # Registry tool functions (publish, renew, moderate)
└── KillSwitch.kt          # Emergency token limit termination
```

## WHERE TO LOOK
| Task | Location |
|------|----------|
| Implement P2P on new container | Implement `P2PInterface` in your container class |
| Route agent request | `P2PRegistry.kt:execute()` — extracts request, finds agent, dispatches |
| Add auth mechanism | `P2PRegistry.kt:authenticate()` — authBody extracted from `transport.transportAuthBody` |
| Create request template | `P2PRegistry.requestTemplates` map, use `AgentRequest.buildRequestFromRegistry()` |
| Host registry server | `P2PHostedRegistry` — publish, query, moderate, audit endpoints |
| Set trust policy | `P2PHostedRegistryPolicy` interface — `canRead`, `canPublish`, `canMutate`, `canModerate` |
| Emergency stop | Attach `KillSwitch` to any `P2PInterface` agent |

## KEY PATTERNS

**Error mapping** (status codes to P2PError):
- `P2PError.auth` → 401 Unauthorized
- `P2PError.prompt` → 422 Unprocessable Entity
- `P2PError.transport` → 429/500 Transport failures

**Transport methods**: `Transport.Tpipe` (internal), `Transport.Http`, `Transport.Stdio`

**Concurrency modes**:
- `P2PConcurrencyMode.SHARED` — one instance handles all requests (default)
- `P2PConcurrencyMode.ISOLATED` — fresh clone/factory per request

**Agent listing entrypoint**: `P2PRegistry.register(transport, descriptor, requirements, agent, concurrencyMode, factory?)`

## ANTI-PATTERNS
- **Never** set `transportAuthBody` on a descriptor returned to external callers — sanitized in `P2PHostedRegistryPolicy.sanitizeListing()`
- **Never** bypass `P2PRegistry.authenticate()` — all inbound requests go through the auth gate
- **Never** use `Transport.Auto` or `Transport.Unknown` in P2P context — throws `IllegalArgumentException`