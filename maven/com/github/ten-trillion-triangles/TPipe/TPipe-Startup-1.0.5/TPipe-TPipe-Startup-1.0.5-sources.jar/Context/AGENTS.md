# Context

## OVERVIEW
Hierarchical memory system: per-run ContextWindow, global persistent ContextBank, multi-page MiniBank, LoreBook keyed injection, token-budgeted truncation.

## STRUCTURE
```
Context/
├── ContextWindow.kt      # Per-run memory, lorebook selection, token budgeting (2,273 LOC)
├── ContextBank.kt        # Global singleton, page key registry, retrieval/write-back (1,737 LOC)
├── MiniBank.kt          # Multi-page context container with merge semantics
├── LoreBook.kt          # Weighted key/value with linkedKeys, aliasKeys, requiredKeys
├── Dict.kt              # Token counting, truncation, word dictionary (623 LOC)
├── StorageMode.kt       # Enum: MEMORY_ONLY, MEMORY_AND_DISK, DISK_ONLY, DISK_WITH_CACHE, REMOTE
├── MemoryClient.kt      # HTTP client for remote memory access (734 LOC)
├── MemoryServer.kt      # Ktor REST API for remote memory endpoints
├── ContextLock.kt       # Global/per-page locking for lorebook and page keys (534 LOC)
├── LockRequest.kt       # Remote lock request payload
├── MemoryTypes.kt       # MemoryErrorType, MemoryOperationResult
├── MemoryPersistence.kt # Disk persistence layer (atomic .bank file I/O)
├── StorageMetadata.kt   # Per-key storage configuration and access stats
├── ConverseData.kt     # ConverseRole enum, ConverseHistory
└── TodoList.kt         # TodoListTask, TodoList for work history
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Lorebook injection | `ContextWindow.kt` | findMatchingLoreBookKeys, checkKeyDependencies |
| Global context | `ContextBank.kt` | bank map, retrievalFunctions, writeBackFunctions |
| Token budgeting | `ContextWindow.kt` | setTokenBudget, calculateAvailableSpace |
| Remote memory sync | `MemoryClient.kt`, `MemoryServer.kt` | REST endpoints, caching |
| Lorebook locking | `ContextLock.kt` | addLock, canSelectLoreBookKey |
| Multi-page merge | `MiniBank.kt` | merge() with emplaceLorebookKeys |

## ANTI-PATTERNS
- **Never** call `setTokenBudget()` while a `Pipe` is executing — thread safety violation