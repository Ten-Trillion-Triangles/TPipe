package com.TTT.Context

import com.TTT.Pipe.MultimodalContent
import com.TTT.PipeContextProtocol.PcpContext
import com.TTT.Util.extractJson
import java.util.UUID
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi

/**
 * Determines chat role of a ConverseData object. This allows the llm to know what the context of what it's
 * talking to is.
 */
enum class ConverseRole
{
    developer,
    system,
    user,
    supervisor,
    agent,
    assistant,
    tool_response,
    pcp_response,
    mcp_response
}

/**
 * Data class that houses one turn of conversation if context is being stored as a chat format.
 * @param role Denotes the role of the thing conversing. LLM's sometimes care about this depending on the provider
 * and api structuring.
 * @param content TPipe multimodal content that makes up the actual generated output of the llm or user request.
 */
@OptIn(ExperimentalSerializationApi::class)
@kotlinx.serialization.Serializable
data class ConverseData(
    var role: ConverseRole,
    var content: MultimodalContent,
    @EncodeDefault(EncodeDefault.Mode.NEVER)
    internal var uuid: String = ""
)
{
    //Assign uuid which we'll use for the equals operator overload.
    fun setUUID()
    {
        uuid = UUID.randomUUID().toString()
    }

    fun getUUID() : String
    {
        val id = uuid
        return id
    }
    
    override operator fun equals(other: Any?): Boolean
    {
        return other is ConverseData && uuid == other.uuid
    }
}

/**
 * Actual class that stores a user to agent conversation history. Houses an array of ConverseData to keep each
 * turn of conversation in order.
 */
@OptIn(ExperimentalSerializationApi::class)
@kotlinx.serialization.Serializable
data class ConverseHistory(
    @EncodeDefault(EncodeDefault.Mode.NEVER)
    val history:  MutableList<ConverseData> = mutableListOf()
)
{
    /**
     * Add to the converse history list using direct supply of role, content, and pcp.
     * This add will be ignored if this object already exists in the array.
     */
    fun add(role: ConverseRole, content: MultimodalContent)
    {
        var converseTurn = ConverseData(role = role, content = content)

        /**
         * There are many wrapping schemes that end up actually already having the content contain the converse history.
         * This will cause confusing nesting when this occurs. So to avoid it and to remove the onus on all containers,
         * and higher level classes that are interacting with this class, we'll adress this behavior by correctly appending
         * as one would expect when you go to add. This allows us to avoid refactors, and any extra steps or confusion
         * when this edge case occurs.
         *
         * FIX: Only attempt nested ConverseHistory extraction if the text appears to be ConverseHistory JSON
         * (starts with "{\"history\""). This prevents AgentRequest JSON or other JSON from being incorrectly parsed.
         */
        val contentJson: ConverseHistory? = if (content.text.trimStart().startsWith("{\"history\""))
        {
            extractJson<ConverseHistory>(content.text)
        }
        else null

        if(contentJson != null)
        {
            history.addAll(contentJson.history)
            return
        }

        converseTurn.setUUID()

        if(history.contains(converseTurn)) return

        history.add(converseTurn)
    }

    /**
     * Add using existing converse data object. This add will be ignored if this object already exists in the array.
     */
    fun add(converseData: ConverseData)
    {
        if(converseData.getUUID().isEmpty()) converseData.setUUID()
        if(history.contains(converseData)) return
        history.add(converseData)
    }

    fun isEmpty() : Boolean
    {
        return history.isEmpty()
    }

}
