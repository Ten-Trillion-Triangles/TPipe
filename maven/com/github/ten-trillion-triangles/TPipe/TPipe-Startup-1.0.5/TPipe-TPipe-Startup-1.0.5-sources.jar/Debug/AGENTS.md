# Debug Package

**Generated:** 2026-04-21
**Commit:** 20613ff5
**Branch:** mcp-server

## OVERVIEW
Tracing system for TPipe pipelines with event capture, visualizers, and remote dispatch.

## STRUCTURE
```
Debug/
├── Trace.kt                     # Stub (2 lines)
├── TraceEvent.kt                # Event data model with metadata
├── TraceEventType.kt            # Central event vocabulary (all container types)
├── TracePhase.kt                # Execution phase enum
├── TraceEventPriority.kt        # Event priority levels
├── TraceDetailLevel.kt          # Verbosity settings
├── TraceFormat.kt               # Output format enum (CONSOLE, HTML, etc)
├── TraceConfig.kt               # Configuration data class
├── PipeTracer.kt                # Central trace storage (ConcurrentHashMap)
├── TraceVisualizer.kt           # Flow chart generation (2,073 LOC)
├── TraceNodeMapper.kt          # Node mapping for visualizer
├── TraceInteractivity.kt        # Interactive trace controls
├── TraceStreamMerger.kt         # Multi-stream aggregation
├── RemoteTraceDispatcher.kt     # HTTP dispatch to TraceServer
├── RemoteTraceConfig.kt         # Remote server config
├── FailureAnalysis.kt           # Post-mortem data class
├── TracingBuilder.kt           # Builder for trace configs
├── GenerateTraceHtml.kt         # HTML export
├── TracingExample.kt           # Usage examples
└── PipeExtensions.kt           # Kotlin extension functions
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Add new trace event type | `TraceEventType.kt` | Enum covers Pipe, Manifold, Junction, Splitter, DistributionGrid |
| Capture new event in pipeline | `PipeTracer.kt` | `addEvent(pipelineId, event)` - thread-safe |
| Generate visual report | `TraceVisualizer.kt:18` | `generateFlowChart(trace)` - handles all container types |
| Remote trace dispatch | `RemoteTraceDispatcher.kt:25` | `dispatchTrace(pipelineId, name, status)` - async HTTP |
| Post-mortem analysis | `FailureAnalysis.kt` | Data class with failure context and suggestions |
| Configure tracing | `TraceConfig.kt` | `maxHistory`, `outputFormat`, `detailLevel`, `autoExport` |

## CONVENTIONS
- Event IDs follow `trace-event-${counter}` pattern
- All Pipeline containers inherit `enableTracing(TraceConfig)` and `trace()` methods
- TraceEvent.metadata uses custom `MapAnySerializer` for JSON serialization
- Remote dispatch uses `AuthRegistry.getToken()` for auth resolution