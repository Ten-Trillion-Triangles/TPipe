# Pipe - Base LLM Interaction

**OVERVIEW**
Base Pipe class for LLM providers: streaming, error handling, token budgeting, context management.

## STRUCTURE
```
Pipe/
├── Pipe.kt                    # 7,224 LOC - base class with streaming, error handling, context management
├── PipeError.kt               # Error capture (eventType, phase, pipeName, timestamp)
├── BinaryContent.kt           # Sealed class: Bytes, Base64String, CloudReference, TextDocument
├── MultimodalContent.kt       # Text + binary + context + metadata + tools container
├── StreamingCallbackManager.kt # Sequential/concurrent callback execution with error isolation
└── StreamingCallbackBuilder.kt # Fluent builder for callback configuration
```

## WHERE TO LOOK
| Task | Location | Notes |
|------|----------|-------|
| Add new provider | `TPipe-Bedrock/src/.../bedrockPipe/` | Extend abstract `Pipe`, implement `generateText()` |
| Streaming implementation | `Pipe.kt:5018-5060` | `generateText()`, `generateContent()`, `execute()` |
| Token budgeting | `Pipe.kt:2485, 2627` | `setTokenBudget()`, `setTokenBudgetInternal()` |
| Error handling | `PipeError.kt` | Captures failure events for programmatic handling |
| Context truncation | `Pipe.kt:4578` | `truncateModuleContext()` abstract method |
| Multimodal content | `BinaryContent.kt` | Binary transport formats and MIME handling |

## CONVENTIONS
- Builder pattern: `setX()` methods return `this` for chaining
- Streaming callbacks: suspend functions with sequential/concurrent modes
- Provider cleanup: `ProviderInterface.cleanPromptText()` for illegal char removal

## ANTI-PATTERNS
- **NEVER** call `setTokenBudget()` while a Pipe is executing -- thread safety violation
- Providers must NOT suppress type errors with `as any`